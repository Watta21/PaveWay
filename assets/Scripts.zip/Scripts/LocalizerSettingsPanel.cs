﻿using System;
using UnityEngine;
using Immersal.XR;

namespace Immersal.Samples
{
    public class LocalizerSettingsPanel : MonoBehaviour
    {
        private XRSpace m_Space;
        
        private void Awake()
        {
            m_Space = FindFirstObjectByType<XRSpace>();
        }

        public void Downsample(bool value)
        {
            ImmersalSDK.Instance.downsample = value;
        }
        
        public void UseProcessing(bool value)
        {
            if (m_Space == null)
                return;
            
            m_Space.ProcessPoses = value;
        }

        public void SetSolverType(int solverTypeIndex)
        {
            foreach (ILocalizationMethod localizationMethod in ImmersalSDK.Instance.Localizer.AvailableLocalizationMethods)
            {
                localizationMethod.Configure(new DefaultLocalizationMethodConfiguration
                {
                    SolverType = (SolverType)solverTypeIndex
                });
            }
        }

        public void SetPriorNNCount(string input)
        {
            int newCount = int.Parse(input);
            foreach (ILocalizationMethod localizationMethod in ImmersalSDK.Instance.Localizer.AvailableLocalizationMethods)
            {
                localizationMethod.Configure(new DefaultLocalizationMethodConfiguration
                {
                    PriorNNCountMin = newCount
                });
            }
        }
        
        public void SetPriorRadius(string input)
        {
            float newRadius = float.Parse(input);
            foreach (ILocalizationMethod localizationMethod in ImmersalSDK.Instance.Localizer.AvailableLocalizationMethods)
            {
                localizationMethod.Configure(new DefaultLocalizationMethodConfiguration
                {
                    PriorRadius = newRadius
                });
            }
        }
        

        public void Pause()
        {
            ImmersalSDK.Instance.Session.PauseSession();
        }

        public void Resume()
        {
            ImmersalSDK.Instance.Session.ResumeSession();
        }

        public void StopLocalizing()
        {
            ImmersalSDK.Instance.Session.StopSession();
        }
        public void StartLocalizing()
        {
            ImmersalSDK.Instance.Session.StartSession();
        }
        public void Localize()
        {
            ImmersalSDK.Instance.Session.LocalizeOnce();
        }

        public void ClosePanel()
        {
            Destroy(this.gameObject);
        }
    }
}
