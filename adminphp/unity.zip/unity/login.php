<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unity_users";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$pass  = isset($_POST['password']) ? $_POST['password'] : '';


if ($email === '') {
    die("NO_EMAIL_PROVIDED");
}

// Query by email now
$sql = "SELECT password, archived, username FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Block archived accounts
    if (isset($row['archived']) && (int)$row['archived'] === 1) {
        echo "ACCOUNT_ARCHIVED";
    } else if (password_verify($pass, $row['password'])) {
        // set session and return success
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION['username'] = !empty($row['username']) ? $row['username'] : $email;
        echo "SUCCESS";
    } else {
        echo "WRONG_PASSWORD";
    }
} else {
    echo "No_User Found";
}

$conn->close();
?>
