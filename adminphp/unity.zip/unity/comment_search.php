<?php
//Script na ito ang nagha-handle ng:
//  ✔ Live search ng comments (username, image_name, comment text)
//  ✔ Pagination (page numbers, previous/next buttons)
// ✔ Pag-generate ng HTML rows para i-load sa admin table
//  ✔ Database query count (total results)
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db_config.php';

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 10;
$offset = ($page - 1) * $perPage;

$whereParts = [];
$params = [];
if ($q !== '') {
    $whereParts[] = '(username LIKE ? OR image_name LIKE ? OR comment LIKE ?)';
    $like = '%' . $q . '%';
    $params[] = $like; $params[] = $like; $params[] = $like;
}
$whereClause = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';

try {
    $countSql = "SELECT COUNT(*) FROM comments " . $whereClause;
    $stmtCount = $pdo->prepare($countSql);
    $stmtCount->execute($params);
    $total = (int)$stmtCount->fetchColumn();

    $selectSql = "SELECT * FROM comments " . $whereClause . " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $stmt = $pdo->prepare($selectSql);
    $bindIndex = 1;
    foreach ($params as $p) {
        $stmt->bindValue($bindIndex++, $p, PDO::PARAM_STR);
    }
    $stmt->bindValue($bindIndex++, (int)$perPage, PDO::PARAM_INT);
    $stmt->bindValue($bindIndex++, (int)$offset, PDO::PARAM_INT);
    $stmt->execute();
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    ob_start();
    if (empty($comments)) {
        echo '<tr class="no-results"><td colspan="5" style="text-align:center;padding:20px;color:#666;">No comments found</td></tr>';
    } else {
        foreach ($comments as $c) {
            echo '<tr data-comment-id="' . (int)$c['id'] . '">';
            echo '<td><div style="display:flex;align-items:center;gap:12px;">';
            echo '<div style="width:40px;height:40px;border-radius:20px;background:#e2e8f0;display:flex;align-items:center;justify-content:center;font-weight:600;color:#4a5568;">' . htmlspecialchars(strtoupper(substr($c['username'],0,1))) . '</div>';
            echo '<div><div style="font-weight:500;">' . htmlspecialchars($c['username']) . '</div></div>';
            echo '</div></td>';
            echo '<td><span style="display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:20px;font-size:0.85em;background:#f1f5f9;color:#64748b;">' . htmlspecialchars($c['image_name']) . '</span></td>';
            $snippet = nl2br(htmlspecialchars($c['comment']));
            echo '<td><div style="max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' . $snippet . '</div></td>';
            echo '<td><div style="color:#4a5568;">' . date('M d, Y', strtotime($c['created_at'])) . '</div><div style="font-size:0.9em;color:#718096;">' . date('h:i A', strtotime($c['created_at'])) . '</div></td>';
            echo '<td><div class="action-buttons"><form method="post" style="display:inline;">';
            echo '<input type="hidden" name="csrf_token" value="' . (isset($_SESSION['csrf_token']) ? htmlspecialchars($_SESSION['csrf_token']) : '') . '" />';
            echo '<input type="hidden" name="comment_id" value="' . (int)$c['id'] . '" />';
            echo '<input type="hidden" name="comment_page" value="' . (int)$page . '" />';
            echo '<button type="submit" name="action" value="delete_comment" class="action-btn delete">Delete</button>';
            echo '</form></div></td>';
            echo '</tr>';
        }
    }
    $html = ob_get_clean();

    // build pagination HTML
    $totalPages = $total > 0 ? ceil($total / $perPage) : 1;
    $pagination = '';
    if ($totalPages > 1) {
        $pagination .= '<div class="pagination">';
        if ($page > 1) $pagination .= '<a href="#" data-page="' . ($page-1) . '" class="page-btn">Previous</a>';
        $maxLinks = 5;
        $start = max(1, $page - floor($maxLinks/2));
        $end = min($totalPages, $start + $maxLinks -1);
        $start = max(1, min($start, $totalPages - $maxLinks + 1));
        if ($start > 1) { $pagination .= '<a href="#" data-page="1" class="page-btn">1</a>'; if ($start > 2) $pagination .= '<span class="page-btn">...</span>'; }
        for ($i = $start; $i <= $end; $i++) {
            if ($i == $page) $pagination .= '<span class="page-btn active">' . $i . '</span>';
            else $pagination .= '<a href="#" data-page="' . $i . '" class="page-btn">' . $i . '</a>';
        }
        if ($end < $totalPages) { if ($end < $totalPages -1) $pagination .= '<span class="page-btn">...</span>'; $pagination .= '<a href="#" data-page="' . $totalPages . '" class="page-btn">' . $totalPages . '</a>'; }
        if ($page < $totalPages) $pagination .= '<a href="#" data-page="' . ($page+1) . '" class="page-btn">Next</a>';
        $pagination .= '</div>';
    }

    echo json_encode(['total'=>$total,'page'=>$page,'per_page'=>$perPage,'html'=>$html,'pagination'=>$pagination]);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['total'=>0,'page'=>$page,'per_page'=>$perPage,'html'=>'','pagination'=>'']);
    exit;
}
