<?php
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "", "unity_users");

if ($conn->connect_error) {
    echo json_encode([
        "status" => "error",
        "message" => "DB connection failed: " . $conn->connect_error
    ]);
    exit();
}

// Get POST data safely
$userInput = isset($_POST['username']) ? $_POST['username'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

if (empty($userInput) || empty($password)) {
    echo json_encode([
        "status" => "error",
        "message" => "Username/email and password are required."
    ]);
    exit();
}

// Prepare statement to prevent SQL injection
$stmt = $conn->prepare("SELECT username, email, password, archived FROM users WHERE email = ? OR username = ? LIMIT 1");
if (!$stmt) {
    echo json_encode([
        "status" => "error",
        "message" => "Prepare statement failed: " . $conn->error
    ]);
    exit();
}

$stmt->bind_param("ss", $userInput, $userInput);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // No user found
    echo json_encode([
        "status" => "error",
        "message" => "Invalid username/email or password."
    ]);
    exit();
}

$user = $result->fetch_assoc();

// Block archived users
if (isset($user['archived']) && (int)$user['archived'] === 1) {
    echo json_encode([
        "status" => "error",
        "message" => "Account archived. Please contact an administrator."
    ]);
    $stmt->close();
    $conn->close();
    exit();
}

// Verify password (assuming passwords are hashed with password_hash())
if (password_verify($password, $user['password'])) {
    // Login success
    echo json_encode([
        "status" => "success",
        "username" => $user['username'],
        "email" => $user['email'],
        "message" => "Login successful"
    ]);
} else {
    // Wrong password
    echo json_encode([
        "status" => "error",
        "message" => "Invalid username/email or password."
    ]);
}

$stmt->close();
$conn->close();
?>
