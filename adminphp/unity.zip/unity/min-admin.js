// Dashboard initialization
document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabId = button.getAttribute('data-tab');
            const button_elem = document.querySelector(`.tab-button[data-tab="${tabId}"]`);
            const content = document.getElementById(tabId);

            if (!button_elem || !content) {
                document.querySelector('.tab-button[data-tab="Dashboard-tab"]').classList.add('active');
                document.getElementById('Dashboard-tab').classList.add('active');
                return;
            }
            // Hide all tabs and remove active class
            tabContents.forEach(tab => tab.classList.remove('active'));
            tabButtons.forEach(btn => btn.classList.remove('active'));

            // Show selected tab and add active class
            content.classList.add('active');
            button_elem.classList.add('active');
        });
    });

    // Check for hash on page load and activate corresponding tab
    const hash = window.location.hash.slice(1);
    if (hash && document.getElementById(hash)) {
        const tabBtn = document.querySelector(`.tab-button[data-tab="${hash}"]`);
        if (tabBtn) {
            tabBtn.click();
        }
    }

    // Tab button click handlers
    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.getAttribute('data-tab');
            window.location.hash = tabId;
        });
    });

    // Sidebar profile dropdown toggle
    const sidebarProfileDropdown = document.querySelector('.sidebar .profile-dropdown');
    if (sidebarProfileDropdown) {
        const sidebarProfileBtn = sidebarProfileDropdown.querySelector('.sidebar-profile-btn');
        function closeSidebarProfile() { sidebarProfileDropdown.classList.remove('open'); }
        sidebarProfileBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            sidebarProfileDropdown.classList.toggle('open');
        });
        document.addEventListener('click', function(e) {
            if (!sidebarProfileDropdown.contains(e.target)) closeSidebarProfile();
        });
        document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeSidebarProfile(); });
    }

    // Store active tab in sessionStorage before form submission
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function() {
            const activeTab = document.querySelector('.tab-content.active').id;
            sessionStorage.setItem('activeTab', activeTab);
        });
    });

    // Restore active tab from sessionStorage on page load
    const storedTab = sessionStorage.getItem('activeTab');
    if (storedTab && document.getElementById(storedTab)) {
        const tabBtn = document.querySelector(`.tab-button[data-tab="${storedTab}"]`);
        if (tabBtn) tabBtn.click();
    }

    // Keep track of active form submission
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function() {
            const activeTab = document.querySelector('.tab-content.active').id;
            sessionStorage.setItem('activeTab', activeTab);
        });
    });

    // Admin form toggle and validation
    const showAdminFormBtn = document.getElementById('showAdminForm');
    const adminForm = document.getElementById('adminForm');
    const cancelAdminFormBtn = document.getElementById('cancelAdminForm');
    const usernameInput = document.getElementById('username');
    const emailInput = document.getElementById('email');
    const usernameStatus = document.getElementById('usernameStatus');
    const emailStatus = document.getElementById('emailStatus');
    const adminFormWarning = document.getElementById('adminFormWarning');
    const submitAdminBtn = document.getElementById('submitAdminBtn');
    const createAdminForm = document.getElementById('createAdminForm');
    
    if (showAdminFormBtn && adminForm && cancelAdminFormBtn) {
        showAdminFormBtn.addEventListener('click', () => {
            adminForm.classList.add('active');
            showAdminFormBtn.style.display = 'none';
            // Clear previous status
            usernameStatus.innerHTML = '';
            emailStatus.innerHTML = '';
            submitAdminBtn.disabled = false;
            adminFormWarning.style.display = 'none';
        });
        
        cancelAdminFormBtn.addEventListener('click', () => {
            adminForm.classList.remove('active');
            showAdminFormBtn.style.display = 'block';
        });
    }
    
    // Check username availability
    if (usernameInput) {
        usernameInput.addEventListener('blur', async function() {
            const username = this.value.trim();
            if (username.length > 0) {
                try {
                    const response = await fetch('check_username.php?username=' + encodeURIComponent(username));
                    const result = await response.json();
                    if (result.exists) {
                        usernameStatus.innerHTML = '⚠️ Username already taken';
                        usernameStatus.style.color = '#dc2626';
                        submitAdminBtn.disabled = true;
                    } else {
                        usernameStatus.innerHTML = '✓ Available';
                        usernameStatus.style.color = '#16a34a';
                        checkFormValidity();
                    }
                } catch (error) {
                    console.error('Error checking username:', error);
                }
            } else {
                usernameStatus.innerHTML = '';
            }
        });
    }
    
    // Check email availability
    if (emailInput) {
        emailInput.addEventListener('blur', async function() {
            const email = this.value.trim();
            if (email.length > 0) {
                try {
                    const response = await fetch('check_email.php?email=' + encodeURIComponent(email));
                    const result = await response.json();
                    if (result.exists) {
                        emailStatus.innerHTML = '⚠️ Email already exists';
                        emailStatus.style.color = '#dc2626';
                        submitAdminBtn.disabled = true;
                    } else {
                        emailStatus.innerHTML = '✓ Available';
                        emailStatus.style.color = '#16a34a';
                        checkFormValidity();
                    }
                } catch (error) {
                    console.error('Error checking email:', error);
                }
            } else {
                emailStatus.innerHTML = '';
            }
        });
    }
    
    // Check form validity
    function checkFormValidity() {
        const usernameTaken = usernameStatus.textContent.includes('already taken');
        const emailTaken = emailStatus.textContent.includes('already exists');
        if (!usernameTaken && !emailTaken) {
            submitAdminBtn.disabled = false;
        }
    }
    
    // Prevent form submission if duplicates detected
    if (createAdminForm) {
        createAdminForm.addEventListener('submit', function(e) {
            const usernameTaken = usernameStatus.textContent.includes('already taken');
            const emailTaken = emailStatus.textContent.includes('already exists');
            if (usernameTaken || emailTaken) {
                e.preventDefault();
                adminFormWarning.textContent = usernameTaken ? '⚠️ Username already taken!' : '⚠️ Email already exists!';
                adminFormWarning.style.display = 'block';
                return false;
            }
        });
    }

    // User Chart.js initialization
    const ctx = document.getElementById('userChart');
    if (ctx) {
        const chart = new Chart(ctx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: window.monthLabels || [],
                datasets: [
                    {
                        label: 'User Registrations',
                        data: window.monthCountsRaw || [],
                        backgroundColor: '#4e73df',
                        borderColor: '#2949c6',
                        borderWidth: 1
                    },
                    {
                        label: 'Comments Posted',
                        data: window.monthCommentsCounts || [],
                        backgroundColor: '#1cc88a',
                        borderColor: '#13a376',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: true, position: 'top' },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            afterLabel: function(ctx) {
                                const monthIdx = ctx.dataIndex;
                                if (ctx.datasetIndex === 1 && window.topImagesPerMonth && window.topImagesPerMonth[monthIdx]) {
                                    return 'Click for top images';
                                }
                                return '';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    }
                }
            }
        });

        // Chart click handler for monthly stats
        ctx.canvas.addEventListener('click', (evt) => {
            const points = chart.getElementsAtEventForMode(evt, 'nearest', { intersect: true }, true);
            if (!points.length) return;
            const datasetIndex = points[0].datasetIndex;
            const dataIndex = points[0].index;
            if (datasetIndex !== 1) return; // Only react to comments dataset
            if (!window.topImagesPerMonth || !window.topImagesPerMonth[dataIndex]) return;

            document.querySelectorAll('.chart-card').forEach(n => n.remove());
            const items = window.topImagesPerMonth[dataIndex];
            if (!items || items.length === 0) return;

            const card = document.createElement('div');
            card.className = 'chart-card';
            const monthName = window.monthLabels ? window.monthLabels[dataIndex] : 'Month ' + (dataIndex + 1);
            card.innerHTML = `<h4>${monthName} - Top Images</h4>`;
            items.forEach(item => {
                const p = document.createElement('p');
                p.innerHTML = `<strong>${item.image}</strong>: ${item.count} comments`;
                card.appendChild(p);
            });
            document.body.appendChild(card);
            // Position near mouse
            setTimeout(() => card.classList.add('visible'), 10);

            let closeCard = () => {
                card.classList.remove('visible');
                setTimeout(() => card.remove(), 300);
                document.removeEventListener('click', closeCard);
            };
            setTimeout(() => document.addEventListener('click', closeCard), 100);
        });
    }
});

// Client-side user filtering by status + search
const userSearch = document.getElementById('userSearch');
const userStatusFilter = document.getElementById('userStatusFilter');
const usersTable = document.getElementById('usersTable');

function applyUserFilters() {
    const q = (userSearch ? userSearch.value.toLowerCase().trim() : '');
    let status = 'all';
    if (userStatusFilter && userStatusFilter.value) status = userStatusFilter.value;
    else {
        try { const p = new URLSearchParams(window.location.search); status = p.get('status') || 'all'; } catch(e){}
    }
    const rows = usersTable ? usersTable.querySelectorAll('tbody tr') : [];
    rows.forEach(row => {
        if (row.classList.contains('no-results')) return;
        const txt = row.textContent.toLowerCase();
        const attr = row.getAttribute('data-archived');
        const isArchived = attr === '1';
        const statusMatch = (status === 'all') || (status === 'active' && !isArchived) || (status === 'archived' && isArchived);
        const textMatch = q === '' || txt.includes(q);
        row.style.display = (statusMatch && textMatch) ? '' : 'none';
    });
}

// Debounce helper
function debounce(fn, ms) {
    let t;
    return function(...args) {
        clearTimeout(t);
        t = setTimeout(() => fn.apply(this, args), ms);
    }
}

// Record previous value on focus
document.addEventListener('focusin', function(e) {
    const el = e.target;
    if (el && el.classList && el.classList.contains('user-status-select')) {
        el.dataset.prevStatus = el.value;
    }
});

if (userSearch) userSearch.addEventListener('input', debounce(applyUserFilters, 150));

// Update pagination links with status filter
function updatePaginationLinksWithStatus(status) {
    if (!usersTable) return;
    const pagContainer = usersTable.parentElement.querySelector('.pagination');
    if (!pagContainer) return;
    const links = pagContainer.querySelectorAll('a');
    links.forEach(a => {
        try {
            const u = new URL(a.getAttribute('href'), window.location.href);
            u.searchParams.set('status', status);
            a.setAttribute('href', u.toString());
        } catch (e) {}
    });
}

if (userStatusFilter) {
    userStatusFilter.addEventListener('change', function(){
        const val = this.value;
        window.location.href = 'min.php?status=' + encodeURIComponent(val) + '&page=1#users-tab';
    });
    updatePaginationLinksWithStatus(userStatusFilter.value);
}

applyUserFilters();

// AJAX handler for user status changes
document.addEventListener('change', function(e){
    const el = e.target;
    if (el && el.classList && el.classList.contains('user-status-select')) {
        const userId = el.getAttribute('data-user-id');
        const newStatus = el.value;
        const prevStatus = el.dataset.prevStatus || (newStatus === 'archived' ? 'active' : 'archived');
        const confirmMsg = newStatus === 'archived' ? 'Are you sure you want to archive this user?' : 'Are you sure you want to activate this user?';
        if (!confirm(confirmMsg)) {
            el.value = prevStatus;
            return;
        }
        const csrf = document.querySelector('input[name="csrf_token"]')?.value || '';
        const row = el.closest('tr');
        if (row) {
            row.setAttribute('data-archived', newStatus === 'archived' ? '1' : '0');
            const badge = row.querySelector('.user-status');
            if (badge) {
                badge.textContent = newStatus === 'archived' ? 'Archived' : 'Active';
                badge.classList.toggle('archived', newStatus === 'archived');
                badge.classList.toggle('active', newStatus !== 'archived');
            }
        }
        fetch('user_status_ajax.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'csrf_token=' + encodeURIComponent(csrf) + '&user_id=' + encodeURIComponent(userId) + '&new_status=' + encodeURIComponent(newStatus)
        }).then(r=>r.json()).then(j=>{
            if (!j.ok) {
                if (row) {
                    row.setAttribute('data-archived', newStatus === 'archived' ? '0' : '1');
                    const badge = row.querySelector('.user-status');
                    if (badge) {
                        badge.textContent = newStatus === 'archived' ? 'Active' : 'Archived';
                        badge.classList.toggle('archived', newStatus !== 'archived');
                        badge.classList.toggle('active', newStatus === 'archived');
                    }
                    const select = row.querySelector('.user-status-select');
                    if (select) select.value = prevStatus;
                }
                alert('Update failed');
            }
        }).catch(()=>{ alert('Network error'); });
    }
});

// Comment search and filtering
const commentSearch = document.getElementById('commentSearch');
const commentFilterBy = document.getElementById('commentFilterBy');
const commentTable = document.getElementById('commentTable');

function filterComments() {
    if (!commentTable) return;
    const filter = commentSearch ? commentSearch.value.toLowerCase() : '';
    const by = commentFilterBy ? commentFilterBy.value : 'all';
    const rows = commentTable.querySelectorAll('tbody tr');
    let anyVisible = false;
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        let hay = '';
        if (by === 'user') hay = (cells[0] ? cells[0].textContent : '').toLowerCase();
        else if (by === 'image') hay = (cells[1] ? cells[1].textContent : '').toLowerCase();
        else if (by === 'comment') hay = (cells[2] ? cells[2].textContent : '').toLowerCase();
        else hay = row.textContent.toLowerCase();
        const show = hay.includes(filter);
        row.style.display = show ? '' : 'none';
        if (show) anyVisible = true;
    });
    const noRow = commentTable.querySelector('tbody tr.no-results');
    if (noRow) noRow.style.display = anyVisible ? 'none' : '';
}

if (commentSearch) commentSearch.addEventListener('input', filterComments);

// Suggestion box for comments
const suggestionBox = document.createElement('div');
suggestionBox.className = 'comment-suggestions';
suggestionBox.style.position = 'absolute';
suggestionBox.style.zIndex = 1200;
suggestionBox.style.background = '#fff';
suggestionBox.style.border = '1px solid rgba(0,0,0,0.08)';
suggestionBox.style.boxShadow = '0 2px 6px rgba(0,0,0,0.08)';
suggestionBox.style.display = 'none';
suggestionBox.style.maxHeight = '240px';
suggestionBox.style.overflowY = 'auto';

const searchBoxParent = document.querySelector('#comments-tab .search-box');
if (searchBoxParent) searchBoxParent.appendChild(suggestionBox);

// Levenshtein distance for fuzzy matching
function levenshtein(a, b) {
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    a = a.toLowerCase(); b = b.toLowerCase();
    const matrix = Array.from({length: b.length + 1}, (_, i) => [i]);
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= b.length; i++){
        for (let j = 1; j <= a.length; j++){
            if (b[i-1] === a[j-1]) matrix[i][j] = matrix[i-1][j-1];
            else matrix[i][j] = Math.min(matrix[i-1][j-1]+1, matrix[i][j-1]+1, matrix[i-1][j]+1);
        }
    }
    return matrix[b.length][a.length];
}

function buildSuggestions() {
    if (!commentTable) return [];
    const rows = Array.from(commentTable.querySelectorAll('tbody tr'))
        .filter(r => !r.classList.contains('no-results'));
    const terms = new Set();
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells[0]) terms.add(cells[0].textContent.trim());
        if (cells[1]) terms.add(cells[1].textContent.trim());
        if (cells[2]) {
            const txt = cells[2].textContent.trim();
            if (txt) terms.add(txt.slice(0, 160));
        }
    });
    return Array.from(terms).filter(t => t.length > 0);
}

function getScoredTerms(query){
    const q = query.trim().toLowerCase();
    if (!q) return [];
    const terms = buildSuggestions();
    const scored = terms.map(term => {
        const t = term.toLowerCase();
        let score = 9999;
        if (t === q) score = 0;
        else if (t.startsWith(q)) score = 1;
        else if (t.includes(q)) score = 2;
        else score = levenshtein(q, t);
        return {term, score};
    });
    const maxAllowed = s => Math.max(2, Math.floor(s.length * 0.45));
    const filtered = scored.filter(s => s.score <= maxAllowed(s.term));
    filtered.sort((a,b)=> a.score - b.score);
    return filtered.slice(0, 10).map(s => s.term);
}

let suggestTimer = null;

async function fetchSuggestions(query) {
    try {
        const res = await fetch('get_suggestions.php?q=' + encodeURIComponent(query));
        if (!res.ok) return [];
        const data = await res.json();
        return Array.isArray(data) ? data : [];
    } catch (e) { return []; }
}

function showServerSuggestions(items, query) {
    suggestionBox.innerHTML = '';
    if (!items || items.length === 0) { suggestionBox.style.display = 'none'; return; }
    const groupBy = {};
    items.forEach(it => { (groupBy[it.type] = groupBy[it.type] || []).push(it); });
    const order = ['user', 'image', 'comment'];
    order.forEach(type => {
        if (!groupBy[type]) return;
        const header = document.createElement('div');
        header.className = 'suggest-header';
        header.style.padding = '6px 10px';
        header.style.fontSize = '12px';
        header.style.color = '#666';
        header.textContent = type === 'user' ? 'Users' : (type === 'image' ? 'Images' : 'Comments');
        suggestionBox.appendChild(header);
        groupBy[type].forEach(itemData => {
            const item = document.createElement('div');
            item.className = 'suggest-item';
            const t = itemData.text;
            const idx = t.toLowerCase().indexOf(query.toLowerCase());
            if (idx >= 0) {
                const before = t.slice(0, idx);
                const match = t.slice(idx, idx + query.length);
                const after = t.slice(idx + query.length);
                item.innerHTML = `${before}<strong>${match}</strong>${after}`;
            } else item.textContent = t;
            item.style.padding = '8px 12px';
            item.style.cursor = 'pointer';
            item.addEventListener('click', function() {
                if (commentSearch) commentSearch.value = itemData.text;
                filterComments();
                suggestionBox.style.display = 'none';
                if (itemData.type === 'user') {
                    const tabBtn = document.querySelector('.tab-button[data-tab="comments-tab"]');
                    if (tabBtn) tabBtn.click();
                }
            });
            suggestionBox.appendChild(item);
        });
    });
    suggestionBox.style.display = 'block';
}

// Comment search with AJAX
async function fetchAndInjectComments(q, page=1) {
    try {
        const res = await fetch('comment_search.php?q=' + encodeURIComponent(q) + '&page=' + encodeURIComponent(page));
        if (!res.ok) return;
        const obj = await res.json();
        const tbody = commentTable ? commentTable.querySelector('tbody') : null;
        if (tbody) tbody.innerHTML = obj.html || '';
        const pagContainer = commentTable ? commentTable.parentElement.querySelector('.pagination') : null;
        if (pagContainer) pagContainer.innerHTML = obj.pagination || '';
        if (pagContainer) {
            const anchors = pagContainer.querySelectorAll('a');
            anchors.forEach(a => {
                a.style.cursor = 'pointer';
                a.addEventListener('click', function(e){
                    e.preventDefault();
                    let p = parseInt(this.getAttribute('data-page')) || NaN;
                    if (!p) {
                        try {
                            const href = this.getAttribute('href') || '';
                            const u = new URL(href, window.location.href);
                            p = parseInt(u.searchParams.get('comment_page') || u.searchParams.get('page')) || 1;
                        } catch (err) {
                            p = 1;
                        }
                    }
                    fetchAndInjectComments(q, p);
                });
            });
        }
    } catch (e) {}
}

if (commentSearch) {
    commentSearch.addEventListener('input', function(){
        filterComments();
        const q = this.value.trim();
        if (suggestTimer) clearTimeout(suggestTimer);
        if (!q) { 
            suggestionBox.style.display='none';
            fetchAndInjectComments('');
            return; 
        }
        suggestTimer = setTimeout(async () => {
            const items = await fetchSuggestions(q);
            showServerSuggestions(items, q);
            fetchAndInjectComments(q, 1);
        }, 180);
    });
    commentSearch.addEventListener('blur', function() { 
        setTimeout(()=> suggestionBox.style.display='none', 150); 
    });
}

// Delegated pagination handler for comments
document.addEventListener('click', function(e) {
    const a = e.target.closest && e.target.closest('.pagination a');
    if (!a) return;
    const pagParent = a.closest('.pagination');
    if (!pagParent) return;
    e.preventDefault();
    let p = parseInt(a.getAttribute('data-page')) || NaN;
    if (!p) {
        try {
            const href = a.getAttribute('href') || '';
            const u = new URL(href, window.location.href);
            p = parseInt(u.searchParams.get('comment_page') || u.searchParams.get('page')) || 1;
        } catch (err) {
            p = 1;
        }
    }
    const q = (commentSearch && commentSearch.value) ? commentSearch.value.trim() : '';
    fetchAndInjectComments(q, p);
});

// Delegated delete handler for comments
document.addEventListener('click', function(e) {
    const deleteBtn = e.target.closest && e.target.closest('button[value="delete_comment"]');
    if (!deleteBtn) return;
    e.preventDefault();
    e.stopPropagation();
    if (!confirm('Permanently delete this comment? This cannot be undone.')) return;
    
    const form = deleteBtn.closest('form');
    if (!form) return;
    const commentId = form.querySelector('input[name="comment_id"]')?.value;
    const commentPage = form.querySelector('input[name="comment_page"]')?.value || 1;
    if (!commentId) { alert('Missing comment ID'); return; }
    
    const csrfInput = document.querySelector('input[name="csrf_token"]');
    const csrf = csrfInput ? csrfInput.value : '';
    if (!csrf) { alert('Missing CSRF token'); return; }
    
    fetch('min.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=delete_comment&comment_id=' + encodeURIComponent(commentId) + '&csrf_token=' + encodeURIComponent(csrf) + '&comment_page=' + encodeURIComponent(commentPage)
    }).then(r => r.text()).then(text => {
        const q = (commentSearch && commentSearch.value) ? commentSearch.value.trim() : '';
        fetchAndInjectComments(q, parseInt(commentPage));
    }).catch(err => { alert('Delete failed: ' + err.message); });
});

// Image stats click handler
document.addEventListener('click', function(e) {
    const item = e.target.closest && e.target.closest('.image-stat-item[data-image]');
    if (!item) return;
    e.preventDefault();
    const imageName = item.getAttribute('data-image') || '';
    if (!imageName) return;
    const commentInput = document.getElementById('commentSearch');
    if (commentInput) commentInput.value = imageName;
    const tabBtn = document.querySelector('.tab-button[data-tab="comments-tab"]');
    if (tabBtn) tabBtn.click();
    if (typeof fetchAndInjectComments === 'function') {
        fetchAndInjectComments(imageName, 1);
    } else {
        try {
            const u = new URL(window.location.href);
            u.searchParams.set('search', imageName);
            u.searchParams.set('comment_page', 1);
            window.location.href = u.toString() + '#comments-tab';
        } catch (err) { }
    }
});
