<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

if (!isset($_POST["username"]) || !isset($_POST["image_id"])) {
    echo 0;
    exit;
}

include __DIR__ . "/conn.php";

$username = $_POST["username"];
$image_id = $_POST["image_id"];

$stmt = $conn->prepare("SELECT visible_step FROM user_image_state WHERE username=? AND image_id=? LIMIT 1");
$stmt->execute([$username, $image_id]);

$row = $stmt->fetch();

echo $row ? $row["visible_step"] : 0;
?>
