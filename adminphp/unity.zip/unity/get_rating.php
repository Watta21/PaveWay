<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "unity_users";

$conn = new mysqli($host, $user, $pass, $db);

$item_id = $_GET['item_id'] ?? '';

if ($item_id == '') {
    echo json_encode(["total_stars" => 0, "total_users" => 0]);
    exit;
}

// Use SUM instead of AVG
$result = $conn->query("SELECT SUM(rating) AS total_stars, COUNT(*) AS total_users 
                        FROM ratings WHERE item_id='$item_id'");

$data = $result->fetch_assoc();

// Ensure numeric values
$data['total_stars'] = $data['total_stars'] ?? 0;
$data['total_users'] = $data['total_users'] ?? 0;

echo json_encode($data);
?>
