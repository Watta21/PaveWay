<?php
session_start();
include("db_config.php"); // This sets up $pdo

$error = "";

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $error = "⚠️ Email not registered";
            } else {
                // block archived users
                if (isset($user['archived']) && (int)$user['archived'] === 1) {
                    $error = "⚠️ Account is archived. Contact an administrator.";
                } else {
                    // support legacy column name 'lockkey' or common 'password'
                    $hashField = isset($user['lockkey']) && $user['lockkey'] ? $user['lockkey'] : (isset($user['password']) ? $user['password'] : '');
                    if ($hashField && password_verify($password, $hashField)) {
                        $_SESSION['username'] = $user['username'] ?? 'Guest';
                        $_SESSION['user_email'] = $user['email'];
                        $_SESSION['profile_pic'] = $user['profile_pic'] ?? '2.png';

                        // Update last activity timestamp
                        $updateStmt = $pdo->prepare("UPDATE users SET last_activity = NOW() WHERE id = ?");
                        $updateStmt->execute([$user['id']]);

                        // Redirect based on role
                        if (isset($user['role']) && $user['role'] === 'admin') {
                            header("Location: min.php");
                        } else {
                            header("Location: index.php");
                        }
                        exit();
                    } else {
                        $error = "❌ Incorrect password.";
                    }
                }
            }
        } catch (PDOException $e) {
            // don't expose DB internals to the user in production; log instead
            error_log('Login error: ' . $e->getMessage());
            $error = "Database error. Please try again later.";
        }
    } else {
        $error = "⚠️ Invalid email format.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <style>
        /* Page */
        html, body {
            height: 100%;
            margin: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: url('2023-03-13.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px; /* allow breathing room on small devices */
            box-sizing: border-box;
        }

        /* subtle blur overlay to soften the background image */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background: rgba(255,255,255,0.02);
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            pointer-events: none; /* allow clicks through */
            z-index: 0;
        }

        /* Container */
        .login-container {
            background: rgba(255,255,255,0.98);
            padding: 20px 24px;
            box-shadow: -2px 14px 20px 20px rgba(0, 0, 0, 0.12);
            border-radius: 10px;
            width: 360px;
            max-width: 100%;
            text-align: center;
            box-sizing: border-box;
            position: relative;
            z-index: 1; /* sits above the blur overlay */
        }

        .login-container h2 {
            margin: 0 0 12px 0;
            font-size: 22px;
            line-height: 1.1;
        }

        /* Branding */
        .brand {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 10px;
        }

        .brand-logo {
            width: 72px;
            height: 72px;
            object-fit: contain;
        }

        .brand-name {
            font-weight: 800;
            color: #0b3d91; /* dark blue */
            font-size: 22px;
        }

        /* Inputs */
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            box-sizing: border-box;
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
            display: block;
        }

        /* Button */
        button {
            width: 100%;
            padding: 12px;
            background: #2563eb; /* nicer blue */
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 6px;
            font-size: 16px;
            margin-top: 10px;
        }

        button:active,
        button:focus {
            outline: none;
            box-shadow: 0 0 0 3px rgba(37,99,235,0.12);
        }

        /* Checkbox and misc */
        .checkbox-container {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            gap: 8px;
            margin-top: 10px;
            font-size: 14px;
        }

        .checkbox-container label {
            cursor: pointer;
            user-select: none;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        .button-group a {
            text-decoration: none;
            margin-top: 2px;
            display: block;
        }

        /* Small screens tweaks */
        @media (max-width: 480px) {
            body {
                /* center the login box on small devices */
                align-items: center !important;
                justify-content: center !important;
                padding-top: 12px;
                min-height: calc(100vh - 24px) !important;
            }

            .login-container {
                padding: 16px;
                width: 100%;
                border-radius: 8px;
                margin: auto !important;
                position: relative;
                top: auto !important;
                transform: none !important;
            }

            .login-container h2 {
                font-size: 20px;
            }

            input[type="text"],
            input[type="email"],
            input[type="password"] {
                padding: 12px;
                font-size: 15px;
            }

            button {
                padding: 12px;
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

<div class="login-container">
    <div class="brand">
        <img src="logo.png" alt="PaveWay logo" class="brand-logo">
        <div class="brand-name"></div>
    </div>
    <h2>Admin</h2>

    <?php if ($error): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post">
    <input type="email" name="email" placeholder="Email" required autocomplete="email">
        <div>
            <input type="password" name="password" id="password" placeholder="Password" required>
        </div>

        <div class="checkbox-container">
            <input type="checkbox" id="showPassword" onclick="togglePasswordVisibility()">
            <label for="showPassword">Show Password</label>
        </div>

        <button type="submit">Login</button>

<div style="margin-top: 10px;">
    <a href="forgot_password.php" style="text-decoration: none;">-----------Forgot Password?-----------</a>
</div>

    </form>

    <!-- Sign up UI removed for admin-only login -->

</div>

<script>
function togglePasswordVisibility() {
    let passwordField = document.getElementById("password");
    let checkbox = document.getElementById("showPassword");
    passwordField.type = checkbox.checked ? "text" : "password";
}
</script>

</body>
</html>
