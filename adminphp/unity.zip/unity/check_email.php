<?php
//check kung existing na ba ang email sa database bago mag-register ang user.
session_start();
header('Content-Type: application/json');
require_once 'db_config.php';

$response = ['exists' => false];

if (isset($_GET['email'])) {
    $email = trim($_GET['email']);
    
    if (!empty($email)) {
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                $response['exists'] = true;
            }
        } catch (PDOException $e) {
            error_log('Error checking email: ' . $e->getMessage());
        }
    }
}

echo json_encode($response);
?>
