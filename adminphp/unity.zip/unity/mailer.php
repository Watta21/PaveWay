<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    // SMTP Server Settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;

    // Fix for localhost SSL issues
    $mail->SMTPOptions = [
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        ]
    ];

    // Encryption and Port
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // TLS
    $mail->Port       = 587;

    // Gmail Login (App Password — no spaces!)
    $mail->Username   = 'cool4cool456@gmail.com';
    $mail->Password   = 'nlhlvsckpqgpheuq';

    // Debug (remove in production)
    $mail->SMTPDebug = 2;
    $mail->Debugoutput = function($str, $level) {
        error_log("SMTP Debug: $str");
    };

    // Sender
    $mail->setFrom('cool4cool456@gmail.com', 'paveway');

    // Recipient (from your database)
    $mail->addAddress($user['email'], $user['username']);

    // Email Content
    $mail->isHTML(true);
    $mail->Subject = 'Password Reset Request';
    $mail->Body    = "
        <h3>Password Reset</h3>
        <p>Click the link below to reset your password:</p>
        <a href='$resetLink'>$resetLink</a>
        <p>This link will expire in 24 hours.</p>
    ";
    $mail->AltBody = "Password reset link: $resetLink";

    // Send Email
    if ($mail->send()) {
        echo "Reset link sent to your email!";
    } else {
        echo "Mailer Error: " . $mail->ErrorInfo;
    }

} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
    error_log("PHPMailer Exception: " . $e->getMessage());
}
?>
