<?php
session_start();

// Include database configuration
global $pdo;
require_once "db_config.php";

// Verify database connection
if (!isset($pdo) || $pdo === null) {
    die("Database connection error: PDO object is not available");
}

$error = "";

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $error = "⚠️ No account found";
            } 
            // 🔒 Check if user account is archived/locked
            elseif (!empty($user['archived']) && strtolower($user['archived']) !== 'active') {
                $error = "🚫 Your account is locked. Please contact support.";
            } 
            elseif (password_verify($password, $user['password'])) {
                // ✅ Allow only admin login
                if (isset($user['role']) && strtolower($user['role']) === 'admin') {
    // Save session data
             $_SESSION['username']    = isset($user['username']) ? $user['username'] : 'Admin';
            $_SESSION['user_email']  = isset($user['email']) ? $user['email'] : '';
             $_SESSION['profile_pic'] = isset($user['profile_pic']) ? $user['profile_pic'] : '2.png';
             $_SESSION['role']        = 'admin';

                    // Update last activity
                    $updateStmt = $pdo->prepare("UPDATE users SET last_activity = NOW() WHERE id = ?");
                    $updateStmt->execute([$user['id']]);

                    // Redirect admin
                    header("Location: min.php");
                    exit();
                } else {
                    // User is not admin → deny login
                    $error = "⚠️ No account found";
                }
            } else {
                $error = "❌ Incorrect password.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = "⚠️ Invalid email format.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('2023-03-13.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            background: white;
            padding: 20px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 300px;
            text-align: center;
        }

        input[type="text"],
        input[type="password"] {
            width: 93%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: blue;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 10px;
        }

        button:hover {
            background: darkblue;
        }

        .checkbox-container {
            display: flex;
            justify-content: flex-start;
            margin-top: 10px;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        .create-account-text {
            margin-top: 15px;
            font-size: 16px;
            color: #555;
        }

        .button-group {
            margin-top: 3px;
        }

        .button-group a {
            text-decoration: none;
            margin-top: 2px;
            display: block;
        }

        @media (max-width: 400px) {
            .login-container {
                width: 90%;
            }
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Admin Login</h2>

    <?php if ($error): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post">
        <input type="text" name="email" placeholder="Email" required>
        <div>
            <input type="password" name="password" id="password" placeholder="Password" required>
        </div>

        <div class="checkbox-container">
            <input type="checkbox" id="showPassword" onclick="togglePasswordVisibility()">
            <label for="showPassword">Show Password</label>
        </div>

        <button type="submit">Login</button>

       
    </form>

