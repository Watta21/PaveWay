<?php
//User Archive / Unarchive Handler (AJAX)
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/db_config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$csrf = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
if (empty($csrf) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrf)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Invalid CSRF token']);
    exit;
}

$userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
$newStatus = isset($_POST['new_status']) ? $_POST['new_status'] : null;
if (!$userId || $newStatus === null) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing parameters']);
    exit;
}

try {
    if ($newStatus === 'archived') {
        $pdo->prepare("UPDATE users SET archived = 1 WHERE id = ?")->execute([$userId]);
    } else {
        $pdo->prepare("UPDATE users SET archived = 0 WHERE id = ?")->execute([$userId]);
    }

    // Also update comments archived flag to match
    $pdo->prepare("UPDATE comments SET archived = ? WHERE Username = (SELECT email FROM users WHERE id = ?)")->execute([$newStatus === 'archived' ? 1 : 0, $userId]);

    echo json_encode(['ok' => true, 'user_id' => $userId, 'archived' => $newStatus === 'archived']);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'DB error']);
    exit;
}
