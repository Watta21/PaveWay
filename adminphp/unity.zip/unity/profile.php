<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit;
}

$username = $_SESSION['username'];
$firstLetter = strtoupper(substr($username, 0, 1)); // Get first letter of the username

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
</head>
<body>
    <h2>Welcome, <?php echo $username; ?>!</h2>
    <p>Your username starts with the letter: <?php echo $firstLetter; ?></p>
    <p><a href="logout.php">Logout</a></p>
</body>
</html>