<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username   = "root"; // default XAMPP user
$password   = "";
$dbname     = "unity_users";

// Connect
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check required POST fields
if (!isset($_POST['username']) || !isset($_POST['email']) || !isset($_POST['password'])) {
    die("MISSING_FIELDS");
}

$user = trim($_POST['username']);
$email = trim($_POST['email']);
$pass = $_POST['password'];

// Basic validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("INVALID_EMAIL");
}

// Hash password securely
$hashedPass = password_hash($pass, PASSWORD_DEFAULT);

// Check if username or email already exists
$sql = "SELECT username, email FROM users WHERE username = ? OR email = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL_ERROR");
}

$stmt->bind_param("ss", $user, $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo "USERNAME_OR_EMAIL_TAKEN";
} else {
    $stmt->close();

    // Insert new user with username, email, hashed password
    $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("SQL_ERROR");
    }

    $stmt->bind_param("sss", $user, $email, $hashedPass);

    if ($stmt->execute()) {
        echo "SUCCESS";
    } else {
        echo "ERROR";
    }
}

$stmt->close();
$conn->close();
?>
