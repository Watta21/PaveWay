<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unity_users";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$image_name = isset($_POST['image_name']) ? $_POST['image_name'] : '';
$comment = isset($_POST['comment']) ? $_POST['comment'] : '';
$user_name = isset($_POST['username']) ? $_POST['username'] : '';

if (!empty($image_name) && !empty($comment) && !empty($user_name)) {
    $stmt = $conn->prepare("INSERT INTO comments (image_name, comment, username) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $image_name, $comment, $user_name);

    if ($stmt->execute()) {
        echo "Comment submitted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid data received";
}

$conn->close();
?>
