<?php
//existing na username sa database bago payagan ang user na mag-register.
session_start();
header('Content-Type: application/json');
require_once 'db_config.php';

$response = ['exists' => false];

if (isset($_GET['username'])) {
    $username = trim($_GET['username']);
    
    if (!empty($username)) {
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            
            if ($stmt->fetch()) {
                $response['exists'] = true;
            }
        } catch (PDOException $e) {
            error_log('Error checking username: ' . $e->getMessage());
        }
    }
}

echo json_encode($response);
?>
