<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

if (!isset($_POST["username"]) || !isset($_POST["image_id"]) || !isset($_POST["visible_step"])) {
    echo "ERROR: Missing fields";
    exit;
}

include __DIR__ . "/conn.php";

$username = $_POST["username"];
$image_id = $_POST["image_id"];
$visible_step = $_POST["visible_step"];

// Check if row exists
$stmt = $conn->prepare("SELECT id FROM user_image_state WHERE username=? AND image_id=?");
$stmt->execute([$username, $image_id]);

if ($stmt->fetch()) {
    // UPDATE
    $update = $conn->prepare("UPDATE user_image_state SET visible_step=? WHERE username=? AND image_id=?");
    $update->execute([$visible_step, $username, $image_id]);
} else {
    // INSERT
    $insert = $conn->prepare("INSERT INTO user_image_state (username, image_id, visible_step) VALUES (?,?,?)");
    $insert->execute([$username, $image_id, $visible_step]);
}

echo "OK";
?>
