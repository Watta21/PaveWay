<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
global $pdo;
require_once "db_config.php";

// Verify database connection
if (!isset($pdo) || $pdo === null) {
    die("Database connection error: PDO object is not available");
}

if (!isset($_SESSION['username'])) {
    $_SESSION['username'] = "User";
}

// CSRF token setup - only create if it doesn't exist
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Update last_seen for current user
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);

    $stmt = $pdo->prepare("SELECT name, email, status FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $current_user = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Get dashboard statistics
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalComments = $pdo->query("SELECT COUNT(*) FROM comments")->fetchColumn();

// Get comments per image
$stmt = $pdo->prepare("
    SELECT image_name, COUNT(*) as comment_count 
    FROM comments 
    WHERE image_name IS NOT NULL 
    GROUP BY image_name 
    ORDER BY comment_count DESC
");
$stmt->execute();
$imageStats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token first - allow certain actions without strict CSRF validation if needed
    $csrfValid = isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']);
    
    if (!$csrfValid) {
        // Regenerate token for next request if it failed
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        // Redirect back with error message via session instead of dying
        $_SESSION['csrf_error'] = true;
        $active_tab = isset($_POST['active_tab']) ? $_POST['active_tab'] : 'users-tab';
        header("Location: min.php#" . $active_tab);
        exit;
    }

    // Get active tab from POST or default to users-tab
    $active_tab = isset($_POST['active_tab']) ? $_POST['active_tab'] : 'users-tab';

    // Handle delete_comment FIRST before other action checks
    if (isset($_POST['action']) && $_POST['action'] === 'delete_comment' && isset($_POST['comment_id'])) {
        $commentId = (int)$_POST['comment_id'];
        $pageToRedirect = isset($_POST['comment_page']) ? max(1, (int)$_POST['comment_page']) : 1;
        // Permanently remove the comment from the database
        $stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
        $stmt->execute([$commentId]);
        header("Location: min.php?comment_page=" . $pageToRedirect . "#comments-tab");
        exit;
    }

    if (isset($_POST['action'], $_POST['user_id'])) {
        $userId = (int)$_POST['user_id'];
        $action = $_POST['action'];
        // Inline status change
        if ($action === 'set_status' && isset($_POST['new_status'])) {
            $newStatus = $_POST['new_status'];
            if ($newStatus === 'archived') {
                // Archive comments and user
                $pdo->prepare("UPDATE comments SET archived = 1 WHERE Username = (SELECT email FROM users WHERE id = ?)")->execute([$userId]);
                $pdo->prepare("UPDATE users SET archived = 1 WHERE id = ?")->execute([$userId]);
            } else {
                // Unarchive comments and user
                $pdo->prepare("UPDATE comments SET archived = 0 WHERE Username = (SELECT email FROM users WHERE id = ?)")->execute([$userId]);
                $pdo->prepare("UPDATE users SET archived = 0 WHERE id = ?")->execute([$userId]);
            }
            header("Location: min.php?status={$filterStatus}&page={$currentPage}#users-tab");
            exit;
        }
        $currentUserPage = isset($_GET['user_page']) ? max(1, (int)$_GET['user_page']) : 1;
        $currentCommentPage = isset($_GET['comment_page']) ? max(1, (int)$_GET['comment_page']) : 1;
        if ($action === 'archive') {
            // Archive the user's comments first
            $pdo->prepare("UPDATE comments SET archived = 1 WHERE Username = (SELECT email FROM users WHERE id = ?)")->execute([$userId]);
            // Then archive the user
            $pdo->prepare("UPDATE users SET archived = 1 WHERE id = ?")->execute([$userId]);
            header("Location: min.php?status={$filterStatus}&page={$currentPage}#users-tab");
            exit;
        // Removed lock functionality as users can now use their account regardless of status
        } elseif ($action === 'make_admin') {
            $stmt = $pdo->prepare("UPDATE users SET is_admin = 1 WHERE id = ?");
            $stmt->execute([$userId]);
        } elseif ($action === 'remove_admin') {
            $stmt = $pdo->prepare("UPDATE users SET is_admin = 0 WHERE id = ?");
            $stmt->execute([$userId]);
        } elseif ($action === 'unarchive') {
            // Unarchive the user's comments first
            $pdo->prepare("UPDATE comments SET archived = 0 WHERE Username = (SELECT email FROM users WHERE id = ?)")->execute([$userId]);
            // Then unarchive the user
            $pdo->prepare("UPDATE users SET archived = 0 WHERE id = ?")->execute([$userId]);
            header("Location: min.php?status={$filterStatus}&page={$currentPage}#users-tab");
            exit;
        } elseif (isset($_POST['action']) && $_POST['action'] === 'archive' && isset($_POST['user_id'])) {
            $userId = (int)$_POST['user_id'];
            $pdo->prepare("UPDATE users SET archived = 1 WHERE id = ?")->execute([$userId]);
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header("Location: min.php?user_page=$currentUserPage#users-tab");
            exit;
        }

        header("Location: min.php#$active_tab");
        exit;
    }

    // handle new creation of admin/ okay to remove
    if (isset($_POST['action']) && $_POST['action'] === 'create_admin' && 
        isset($_POST['username'], $_POST['email'], $_POST['password'])) {
        
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        
        // Basic validation
        if (empty($username) || empty($email) || empty($password)) {
            $_SESSION['error'] = "All fields are required";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['error'] = "Invalid email format";
        } else {
            // Check if username already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            
            if ($stmt->fetch()) {
                $_SESSION['error'] = "Username already taken";
            } else {
                // Check if email already exists
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);

                if ($stmt->fetch()) {
                    $_SESSION['error'] = "Email already exists";
                } else {
                    // Hash password and create user
                    $role = 'admin';
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, created_at, status) 
                        VALUES (?, ?, ?, ?, NOW(), 'active')");
                    $stmt->execute([$username, $email, $hashedPassword, $role]);

                    $_SESSION['success'] = "Admin user created successfully";
                }
            }
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        header("Location: min.php#$active_tab");
        exit;
    }
    
}



// Pagination settings
$perPage = 10;

// Get the filter status from URL parameter
$filterStatus = isset($_GET['status']) ? $_GET['status'] : 'all';

// Build the WHERE clause based on filter
$whereClause = '';
if ($filterStatus === 'archived') {
    $whereClause = 'WHERE archived = 1';
} elseif ($filterStatus === 'active') {
    $whereClause = 'WHERE archived = 0';
} else {
    // 'all' shows both active and archived users
    $whereClause = '';
}

// Count total users for pagination
$countQuery = "SELECT COUNT(*) FROM users " . $whereClause;
$totalUsers = $pdo->query($countQuery)->fetchColumn();
$totalPages = ceil($totalUsers / $perPage);
$currentPage = isset($_GET['page']) ? max(1, min($totalPages, (int)$_GET['page'])) : 1;
$offset = ($currentPage - 1) * $perPage;

// Fetch users with pagination and filter
$query = "SELECT id, username, email, created_at, status, last_seen, last_activity, archived, 
    TIMESTAMPDIFF(MINUTE, last_seen, NOW()) AS minutes_ago, role 
    FROM users " . $whereClause . " 
    ORDER BY created_at DESC LIMIT $perPage OFFSET $offset";
$users = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);

// Comments pagination
$totalComments = $pdo->query("SELECT COUNT(*) FROM comments")->fetchColumn();
$totalCommentPages = ceil($totalComments / $perPage);
$currentCommentPage = isset($_GET['comment_page']) ? max(1, min($totalCommentPages, (int)$_GET['comment_page'])) : 1;
$commentOffset = ($currentCommentPage - 1) * $perPage;

// Get the filter/status and search from URL parameters
$filterStatus = isset($_GET['status']) ? $_GET['status'] : 'all';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build WHERE parts and params for prepared statements
$whereParts = [];
$params = [];
if ($filterStatus === 'archived') {
    $whereParts[] = 'archived = 1';
} elseif ($filterStatus === 'active') {
    $whereParts[] = 'archived = 0';
} elseif ($filterStatus === 'locked') {
    $whereParts[] = 'status = "locked"';
}

if ($search !== '') {
    $whereParts[] = '(username LIKE ? OR email LIKE ? OR role LIKE ?)';
    $like = '%' . $search . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$whereClause = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';

// Count total users for pagination (prepared)
$countSql = "SELECT COUNT(*) FROM users " . $whereClause;
$stmtCount = $pdo->prepare($countSql);
$stmtCount->execute($params);
$totalUsers = (int)$stmtCount->fetchColumn();
$totalPages = $totalUsers > 0 ? ceil($totalUsers / $perPage) : 1;
$currentPage = isset($_GET['page']) ? max(1, min($totalPages, (int)$_GET['page'])) : 1;
$offset = ($currentPage - 1) * $perPage;

// Fetch users with pagination and filter (prepared)
$selectSql = "SELECT id, username, email, created_at, status, last_seen, last_activity, archived, 
    TIMESTAMPDIFF(MINUTE, last_seen, NOW()) AS minutes_ago, role 
    FROM users " . $whereClause . " 
    ORDER BY created_at DESC LIMIT ? OFFSET ?";
$stmt = $pdo->prepare($selectSql);

// bind params
$bindIndex = 1;
foreach ($params as $p) {
    $stmt->bindValue($bindIndex++, $p, PDO::PARAM_STR);
}
$stmt->bindValue($bindIndex++, (int)$perPage, PDO::PARAM_INT);
$stmt->bindValue($bindIndex++, (int)$offset, PDO::PARAM_INT);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch comments with pagination

$comments = $pdo->query("
    SELECT * FROM comments 
    WHERE archived = 0
    ORDER BY created_at DESC
    LIMIT $perPage OFFSET $commentOffset
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch ratings with pagination
$ratingsPerPage = 20;
$currentRatingPage = isset($_GET['rating_page']) ? max(1, (int)$_GET['rating_page']) : 1;
$ratingOffset = ($currentRatingPage - 1) * $ratingsPerPage;

// Build WHERE clause for server-side filtering
$whereClause = "WHERE 1=1";
$params = array();

if (isset($_GET['rating_filter']) && $_GET['rating_filter'] !== '') {
    $ratingValue = (int)$_GET['rating_filter'];
    $whereClause .= " AND rating = ?";
    $params[] = $ratingValue;
}

if (isset($_GET['image_filter']) && $_GET['image_filter'] !== '') {
    $imageName = $_GET['image_filter'];
    $whereClause .= " AND image_name = ?";
    $params[] = $imageName;
}

// Count total ratings with filters
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM ratings $whereClause");
$countStmt->execute($params);
$totalRatings = $countStmt->fetchColumn();
$totalRatingPages = ceil($totalRatings / $ratingsPerPage);
$currentRatingPage = min($currentRatingPage, max(1, $totalRatingPages));

// Fetch ratings with pagination and filters
$ratingOffset = ($currentRatingPage - 1) * $ratingsPerPage;
$stmt = $pdo->prepare("
    SELECT image_name, username, rating FROM ratings 
    $whereClause
    ORDER BY image_name, username
    LIMIT $ratingsPerPage OFFSET $ratingOffset
");
$stmt->execute($params);
$allRatings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get ratings by image for dashboard cards
$imageRatings = $pdo->query("
    SELECT image_name, COUNT(*) as total_ratings, SUM(rating) as total_rating_sum
    FROM ratings
    GROUP BY image_name
    ORDER BY total_rating_sum DESC
    LIMIT 12
")->fetchAll(PDO::FETCH_ASSOC);

// Get star breakdown for specific images in ratings section
$specificImages = ['NGC', 'BIR', 'SSS', 'PhilHealth', 'CityHealth'];
$imageStarBreakdowns = [];
$imageAverages = [];

foreach ($specificImages as $imageName) {
    $imageStarBreakdowns[$imageName] = [];
    for ($star = 1; $star <= 5; $star++) {
        $result = $pdo->query("SELECT COUNT(*) as count, SUM(rating) as total_sum FROM ratings WHERE image_name = '$imageName' AND rating = $star")->fetch(PDO::FETCH_ASSOC);
        $imageStarBreakdowns[$imageName][$star] = [
            'count' => (int)($result['count'] ?? 0),
            'sum' => (int)($result['total_sum'] ?? 0)
        ];
    }
    
    // Calculate average rating for this image
    $avgResult = $pdo->query("SELECT AVG(rating) as avg_rating, COUNT(*) as total_count FROM ratings WHERE image_name = '$imageName'")->fetch(PDO::FETCH_ASSOC);
    $imageAverages[$imageName] = [
        'average' => $avgResult['avg_rating'] ? round($avgResult['avg_rating'], 2) : 0,
        'total' => (int)($avgResult['total_count'] ?? 0)
    ];
}

// Monthly registration stats
$monthlyStatsRaw = $pdo->query("
    SELECT MONTH(created_at) AS month, COUNT(*) AS total
    FROM users
    WHERE YEAR(created_at) = YEAR(CURDATE())
    GROUP BY MONTH(created_at)
")->fetchAll(PDO::FETCH_ASSOC);

$statsMap = array_column($monthlyStatsRaw, 'total', 'month');

$monthLabels = [];
$monthCountsRaw = [];
for ($i = 1; $i <= 12; $i++) {
    $monthLabels[] = date("F", mktime(0, 0, 0, $i, 1));
    $count = isset($statsMap[$i]) ? $statsMap[$i] : 0;

    $monthCountsRaw[] = $count;
}

// --- New: compute comment stats per month for the current year ---
$commentsByMonthRaw = $pdo->query("SELECT MONTH(created_at) AS month, COUNT(*) AS total FROM comments WHERE YEAR(created_at) = YEAR(CURDATE()) GROUP BY MONTH(created_at)")->fetchAll(PDO::FETCH_ASSOC);
$commentsMap = array_column($commentsByMonthRaw, 'total', 'month');

$monthCommentsCounts = [];
$topImagesPerMonth = []; // array of arrays: each item is [[image, count], ...]
$latestComments = [];
for ($m = 1; $m <= 12; $m++) {
    $monthCommentsCounts[] = isset($commentsMap[$m]) ? (int)$commentsMap[$m] : 0;

    // Top 5 images for month
    $stmtImg = $pdo->prepare("SELECT image_name, COUNT(*) AS c FROM comments WHERE MONTH(created_at) = ? AND YEAR(created_at) = YEAR(CURDATE()) GROUP BY image_name ORDER BY c DESC LIMIT 5");
    $stmtImg->execute([$m]);
    $top5 = $stmtImg->fetchAll(PDO::FETCH_ASSOC);
    $list = [];
    foreach ($top5 as $row) {
        $thumbPath = '';
        // If image file exists in the same directory, use it as thumbnail
        $possible = __DIR__ . DIRECTORY_SEPARATOR . $row['image_name'];
        if (!empty($row['image_name']) && file_exists($possible)) {
            $thumbPath = $row['image_name'];
        }
        $list[] = ['image' => $row['image_name'], 'count' => (int)$row['c'], 'thumb' => $thumbPath];
    }
    $topImagesPerMonth[] = $list;

    // Latest comment for month
    $stmtLatest = $pdo->prepare("SELECT comment, image_name FROM comments WHERE MONTH(created_at) = ? AND YEAR(created_at) = YEAR(CURDATE()) ORDER BY created_at DESC LIMIT 1");
    $stmtLatest->execute([$m]);
    $latest = $stmtLatest->fetch(PDO::FETCH_ASSOC);
    $latestComments[] = $latest ? $latest['comment'] : '';
}

$monthCountsScaled = $monthCountsRaw;
$totalUsersYear = array_sum($monthCountsScaled);
$monthPercentages = [];
for ($i = 0; $i < count($monthCountsScaled); $i++) {
    $count = $monthCountsScaled[$i];
    if ($totalUsersYear <= 100) {
        $monthPercentages[] = $count;
    } else {
        $monthPercentages[] = $totalUsersYear > 0 ? round(($count / $totalUsersYear) * 100, 1) : 0;
    }
}
$maxScaled = max(max($monthCountsScaled), 100);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
     <link rel="stylesheet" href="min.css"> <!-- External CSS -->
    <style>
    /* Reset and base */
    * {
        box-sizing: border-box;
    }

    /* Chart popup card */
        .chart-card {
        position: fixed;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        padding: 16px;
        min-width: 260px;
        max-width: 320px;
        border: 1px solid #eee;
        z-index: 1000;
        opacity: 0;
        transform: translateY(-10px);
        transition: opacity 0.2s, transform 0.2s;
    }
    .chart-card.visible {
        opacity: 1;
        transform: translateY(0);
    }
    .chart-card::after {
        content: '';
        position: absolute;
        left: 12px;
        bottom: -8px;
        width: 0;
        height: 0;
        border-left: 8px solid transparent;
        border-right: 8px solid transparent;
        border-top: 8px solid #fff;
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
    }
    .chart-card h4 { margin: 0 0 6px 0; font-size: 14px; }
    .chart-card p { margin: 4px 0; font-size: 13px; color: #333; }
    .chart-card .top-images { display:flex; flex-direction:column; gap:6px; margin-top:6px; }
    .chart-card .top-images .item { display:flex; align-items:center; gap:8px; }
    .chart-card .top-images img { width:40px; height:40px; object-fit:cover; border-radius:4px; }
    .chart-card .top-images .meta { font-size:13px; color:#222; }

    .month-cards {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        margin: 24px 0;
        justify-content: center;
    }
    .month-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        padding: 20px 28px;
        min-width: 120px;
        text-align: center;
        transition: box-shadow 0.2s;
        border: 1px solid #eee;
    }
    .month-card:hover {
        box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        border-color: #cce;
    }
    .month-title {
        font-size: 1.1em;
        font-weight: 600;
        margin-bottom: 8px;
        color: #3a3a3a;
    }
    .month-value {
        font-size: 1.4em;
        font-weight: 700;
        color: #2a7ae2;
    }

    .stats-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stats-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        padding: 20px;
        border: 1px solid #eef1f5;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    
    .stats-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(0,0,0,0.1);
    }
    
    .stats-card:nth-child(1) {
        background: linear-gradient(135deg, #ff6b6b 0%, #ff8585 100%);
    }
    
    .stats-card:nth-child(2) {
        background: linear-gradient(135deg, #4e73df 0%, #6384e5 100%);
    }
    
    .stats-card:nth-child(3) {
        background: linear-gradient(135deg, #1cc88a 0%, #2fdba2 100%);
    }

    /* User Page Styles */
    .user-page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
    }

    .user-page-title {
        font-size: 1.5em;
        color: #2d3748;
        font-weight: 600;
    }

    .user-controls {
        background: white;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        margin-bottom: 24px;
        display: flex;
        gap: 16px;
        align-items: center;
        flex-wrap: wrap;
    }

    .user-table {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        overflow: hidden;
        margin-bottom: 24px;
    }

    .user-table table {
        width: 100%;
        border-collapse: collapse;
    }

    .user-table th {
        background: #f8f9fc;
        padding: 16px;
        text-align: left;
        font-weight: 600;
        color: #4a5568;
        border-bottom: 2px solid #e2e8f0;
    }

    .user-table td {
        padding: 16px;
        border-bottom: 1px solid #e2e8f0;
        color: #2d3748;
    }

    .user-status {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85em;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .user-status.active {
        background: #dcfce7;
        color: #15803d;
    }

    .user-status.locked {
        background: #fee2e2;
        color: #b91c1c;
    }

    .user-status.archived {
        background: #fee2e2;
        color: #991b1b;
    }

    .search-box {
        position: relative;
        flex: 1;
        min-width: 200px;
    }

    .search-box input {
        width: 100%;
        padding: 12px 16px;
        padding-left: 40px;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        font-size: 0.95em;
        transition: all 0.2s;
    }

    .search-box input:focus {
        outline: none;
        border-color: #4e73df;
        box-shadow: 0 0 0 3px rgba(78, 115, 223, 0.1);
    }

    .filter-select {
        padding: 12px 16px;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        font-size: 0.95em;
        min-width: 160px;
        background: white;
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .stats-title {
        font-size: 0.9em;
        color: rgba(255, 255, 255, 0.9);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
    }
    
    .stats-value {
        font-size: 2em;
        font-weight: 600;
        color: white;
        margin-bottom: 8px;
        text-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .image-stats {
        margin-top: 12px;
        max-height: 300px;
        overflow-y: auto;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        padding: 8px;
    }
    
    .image-stat-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .image-stat-item:last-child {
        border-bottom: none;
    }
    
    .image-name {
        font-weight: 500;
        color: rgba(255, 255, 255, 0.9);
    }
    
    .comment-count {
        background: rgba(255, 255, 255, 0.2);
        color: white;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 0.9em;
        font-weight: 500;
    }

    /* User Page Styles */
    .user-controls {
        background: white;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        margin-bottom: 24px;
        display: flex;
        gap: 16px;
        align-items: center;
        flex-wrap: wrap;
    }

    .search-box {
        flex: 1;
        min-width: 200px;
        position: relative;
    }

    .search-box input {
        width: 100%;
        padding: 12px 16px;
        padding-left: 40px;
        border: 1px solid #e0e4e8;
        border-radius: 8px;
        font-size: 0.95em;
        transition: all 0.2s;
    }

    .search-box input:focus {
        outline: none;
        border-color: #4e73df;
        box-shadow: 0 0 0 3px rgba(78, 115, 223, 0.1);
    }

    .search-box::before {
        content: '';
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        width: 16px;
        height: 16px;
        background: url('icons/search.svg') no-repeat center;
        opacity: 0.5;
    }

    .filter-select {
        padding: 12px 16px;
        border: 1px solid #e0e4e8;
        border-radius: 8px;
        font-size: 0.95em;
        min-width: 160px;
        background: white;
        cursor: pointer;
        transition: all 0.2s;
    }

    .filter-select:focus {
        outline: none;
        border-color: #4e73df;
        box-shadow: 0 0 0 3px rgba(78, 115, 223, 0.1);
    }

    .user-table {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        overflow: hidden;
    }

    .user-table table {
        width: 100%;
        border-collapse: collapse;
    }

    .user-table th {
        background: #f8f9fc;
        padding: 16px;
        text-align: left;
        font-weight: 600;
        color: #4a5568;
        border-bottom: 2px solid #e2e8f0;
    }

    .user-table td {
        padding: 16px;
        border-bottom: 1px solid #e2e8f0;
        color: #2d3748;
    }

    .user-table tr:last-child td {
        border-bottom: none;
    }

    .user-table tr:hover {
        background: #f8faff;
    }

    .user-status {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85em;
        font-weight: 500;
        display: inline-block;
    }

    .user-status.active {
        background: #e6ffec;
        color: #1cc88a;
    }

    .user-status.archived {
        background: #fee2e2;
        color: #991b1b;
    }

    .action-buttons {
        display: flex;
        gap: 8px;
    }

    .action-btn {
        padding: 6px 12px;
        border: none;
        border-radius: 6px;
        font-size: 0.9em;
        cursor: pointer;
        transition: all 0.2s;
        background: #f1f5f9;
        color: #475569;
    }

    .action-btn:hover {
        background: #e2e8f0;
    }

    .action-btn.delete {
        background: #fff5f5;
        color: #ff4e4e;
    }

    .action-btn.delete:hover {
        background: #ffe5e5;
    }

    .pagination {
        display: flex;
        justify-content: center;
        gap: 8px;
        margin-top: 24px;
    }

    .page-btn {
        padding: 8px 16px;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        background: white;
        color: #4a5568;
        cursor: pointer;
        transition: all 0.2s;
    }

    .page-btn:hover {
        background: #f8f9fc;
        border-color: #cbd5e0;
    }

    .page-btn.active {
        background: #4e73df;
        color: white;
        border-color: #4e73df;
    }

    /* New styles for ratings section */
    #ratings-section {
        margin-top: 32px;
    }
    #ratings-section h2 {
        font-size: 1.5em;
        margin-bottom: 16px;
        color: #2d3748;
        font-weight: 600;
    }
    #ratings-section .user-table {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        overflow: hidden;
    }
    #ratings-section table {
        width: 100%;
        border-collapse: collapse;
    }
    #ratings-section th {
        background: #f8f9fc;
        padding: 16px;
        text-align: left;
        font-weight: 600;
        color: #4a5568;
        border-bottom: 2px solid #e2e8f0;
    }
    #ratings-section td {
        padding: 16px;
        border-bottom: 1px solid #e2e8f0;
        color: #2d3748;
    }
    #ratings-section tr:last-child td {
        border-bottom: none;
    }
    #ratings-section tr:hover {
        background: #f8faff;
    }
    </style>
</head>
<body>
<header>
        <span class="paveway-text"><span class="pave">Pave</span><span class="way">Way</span></span>
    </div>
    <!-- profile-dropdown moved to sidebar for bottom placement -->
</header>

<div class="sidebar">
    <div class="sidebar-logo" style="margin-bottom: 0px; text-align: center;">
        <img src="ogo.png" alt="Logo" style="max-width: 100px; height: auto;" />
    </div>
    <h2>Menu</h2>
    <button class="tab-button active" data-tab="Dashboard-tab">
        <span class="icon"><img src="icons/home.svg" alt="Home" /></span>
        <span class="label">Home</span>
    </button>
    <button class="tab-button" data-tab="users-tab">
        <span class="icon"><img src="icons/users.svg" alt="Users" /></span>
        <span class="label">Users</span>
    </button>
    <button class="tab-button" data-tab="comments-tab">
        <span class="icon icon-circle"><img src="icons/comments.svg" alt="Comments" /></span>
        <span class="label">Comments</span>
    </button>
    <button class="tab-button" data-tab="ratings-section">
        <span class="icon"><i class="fas fa-star" style="color: #fbbf24; font-size: 1.2em; filter: none;"></i></span>
        <span class="label">Ratings</span>
    </button>
    
    <!-- move profile button to bottom of sidebar -->
    <div class="sidebar-profile">
        <div class="profile-dropdown">
            <button class="profile-btn sidebar-profile-btn">
                <div class="profile-img"><?= (isset($current_user['name']) && $current_user['name']) ? strtoupper(substr($current_user['name'], 0, 1)) : (isset($_SESSION['username']) && $_SESSION['username'] ? strtoupper(substr($_SESSION['username'], 0, 1)) : 'A') ?></div>
                <span class="sidebar-profile-name"><?= (isset($current_user['name']) && $current_user['name']) ? htmlspecialchars($current_user['name']) : (isset($_SESSION['username']) && $_SESSION['username'] ? htmlspecialchars($_SESSION['username']) : 'Admin') ?></span>
            </button>
            <div class="dropdown-content">
                <div class="dropdown-header"><?= isset($current_user['name']) ? htmlspecialchars($current_user['name']) : 'Admin' ?></div>
                <div class="dropdown-divider"></div>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <section id="Dashboard-tab" class="tab-content active">
        <div class="stats-cards">
            <div class="stats-card">
                <div class="stats-title">Total Users</div>
                <div class="stats-value"><?= number_format($totalUsers) ?></div>
                <div style="color: rgba(255, 255, 255, 0.8); font-size: 0.9em;">Registered accounts</div>
            </div>
            
            <div class="stats-card">
                <div class="stats-title">Total Comments</div>
                <div class="stats-value"><?= number_format($totalComments) ?></div>
                <div style="color: rgba(255, 255, 255, 0.8); font-size: 0.9em;">Comments posted</div>
            </div>
            
            <div class="stats-card">
                <div class="stats-title">Comments per Image</div>
                <div class="image-stats">
                    <?php foreach ($imageStats as $stat): ?>
                        <div class="image-stat-item" data-image="<?= htmlspecialchars($stat['image_name']) ?>">
                            <div class="image-name"><?= htmlspecialchars($stat['image_name']) ?></div>
                            <div class="comment-count"><?= number_format($stat['comment_count']) ?></div>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($imageStats)): ?>
                        <div style="color: rgba(255, 255, 255, 0.8); text-align: center; padding: 20px;">No comments yet</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <h2 style="margin-top: 40px; color: #333; font-size: 1.3em;">Image Ratings Breakdown</h2>
        <!-- Specific Images Star Breakdown Cards -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; margin-bottom: 30px; margin-top: 20px;">
            <?php foreach ($specificImages as $imageName): ?>
                <div style="background: #f3f4f6; border-radius: 8px; padding: 10px; box-shadow: 0 1px 4px rgba(0,0,0,0.08);">
                    <h3 style="color: #333; font-size: 0.9em; margin: 0 0 8px 0; font-weight: 600;"><?= htmlspecialchars($imageName) ?></h3>
                    <div style="display: flex; flex-direction: column; gap: 6px;">
                        <?php for ($star = 1; $star <= 5; $star++): ?>
                            <button class="star-filter-btn" data-image="<?= htmlspecialchars($imageName) ?>" data-rating="<?= $star ?>" style="background: white; border: 1px solid #e5e7eb; border-radius: 4px; display: flex; justify-content: space-between; align-items: center; padding: 4px 8px; cursor: pointer; transition: background 0.2s, border-color 0.2s; font-size: 0.8em;">
                                <div style="font-weight: 500; color: #333; font-size: 0.75em;">
                                    <?php for ($i = 0; $i < $star; $i++): ?>
                                        <span style="color: #f59e0b; font-size: 0.75em;">★</span>
                                    <?php endfor; ?>
                                </div>
                                <div style="color: #666; font-weight: 600; font-size: 0.75em; display: flex; gap: 4px;">
                                    <span><?= $imageStarBreakdowns[$imageName][$star]['count'] ?></span>
                                    <span style="color: #999;">|</span>
                                    <span><?= $imageStarBreakdowns[$imageName][$star]['sum'] ?>★</span>
                                </div>
                            </button>
                        <?php endfor; ?>
                    </div>
                    <!-- Total Stars Display -->
                    <div style="margin-top: 10px; padding: 8px; background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-radius: 6px; text-align: center;">
                        <div style="font-size: 0.65em; color: #92400e; font-weight: 600; margin-bottom: 4px; letter-spacing: 0.5px;">STATS</div>
                        <div style="display: flex; align-items: center; justify-content: center; gap: 6px; flex-wrap: wrap;">
                            <div style="flex: 1; min-width: 50px;">
                                <div style="font-size: 1em; font-weight: 800; color: #f59e0b;">
                                    <?php 
                                        $totalStars = 0;
                                        for ($s = 1; $s <= 5; $s++) {
                                            $totalStars += $imageStarBreakdowns[$imageName][$s]['sum'];
                                        }
                                        echo $totalStars;
                                    ?>
                                </div>
                                <div style="font-size: 0.6em; color: #92400e; font-weight: 600;">★</div>
                            </div>
                            <div style="width: 1px; height: 20px; background: #fcd34d;"></div>
                            <div style="flex: 1; min-width: 50px;">
                                <div style="font-size: 1em; font-weight: 800; color: #f59e0b;">
                                    <?= $imageAverages[$imageName]['average'] ?><span style="font-size: 0.8em;">★</span>
                                </div>
                                <div style="font-size: 0.6em; color: #92400e; font-weight: 600;">Avg</div>
                            </div>
                            <div style="width: 1px; height: 20px; background: #fcd34d;"></div>
                            <div style="flex: 1; min-width: 50px;">
                                <div style="font-size: 1em; font-weight: 800; color: #f59e0b;">
                                    <?= $imageAverages[$imageName]['total'] ?>
                                </div>
                                <div style="font-size: 0.6em; color: #92400e; font-weight: 600;">Users</div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <h2>User Registration Chart</h2>
        <div class="chart-card-wrap">
            <canvas id="userChart"></canvas>
        </div>
        <!-- month cards removed; only the chart remains -->
    </section>

    <section id="users-tab" class="tab-content">
        <div class="user-controls">
            <div class="search-box">
                <input type="text" id="userSearch" placeholder="Search users by name, email..." autocomplete="off">
            </div>
            <select id="userStatusFilter" class="filter-select" onchange="filterUsers(this.value)">
                <option value="all" <?= ($filterStatus === 'all' ? 'selected' : '') ?>>All Users</option>
                <option value="active" <?= ($filterStatus === 'active' ? 'selected' : '') ?>>Active Users</option>
                <option value="archived" <?= ($filterStatus === 'archived' ? 'selected' : '') ?>>Archived Users</option>
            </select>
            <button id="showAdminForm" class="action-btn" style="background: #4e73df; color: white; padding: 12px 20px;">
                <i class="fas fa-plus"></i> Create Admin
            </button>
        </div>
        
        <div id="adminForm" class="admin-form">
            <h3>Create New Admin User</h3>
            <?php if (isset($_SESSION['error'])): ?>
                <div class="error-message"><?= $_SESSION['error'] ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="success-message"><?= $_SESSION['success'] ?></div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>
            <div id="adminFormWarning" class="error-message" style="display:none;"></div>
            <form method="post" id="createAdminForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>" />
                <input type="hidden" name="action" value="create_admin" />
                <input type="hidden" name="active_tab" value="users-tab" />
                
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                    <span id="usernameStatus" style="font-size: 0.85em; margin-top: 4px; display: block;"></span>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                    <span id="emailStatus" style="font-size: 0.85em; margin-top: 4px; display: block;"></span>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <div class="form-actions">
                    <button type="button" id="cancelAdminForm" class="btn btn-delete">Cancel</button>
                    <button type="submit" class="btn btn-admin" id="submitAdminBtn">Create Admin</button>
                </div>
            </form>
        </div>
        
        <div class="user-table">
            <table id="usersTable">
                <thead>
                    <tr>
                        <th>User Info</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Joined Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 40px; color: #666;">
                            No users found with the selected filter
                        </td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($users as $user): ?>
                    <tr data-archived="<?= $user['archived'] ? '1' : '0' ?>">
                        <td>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 40px; height: 40px; border-radius: 20px; background: <?= $user['role'] === 'admin' ? '#4e73df' : '#e2e8f0' ?>; display: flex; align-items: center; justify-content: center; font-weight: 600; color: <?= $user['role'] === 'admin' ? 'white' : '#4a5568' ?>;">
                                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                </div>
                                <div>
                                    <div style="font-weight: 500;"><?= htmlspecialchars($user['username']) ?></div>
                                    <div style="font-size: 0.9em; color: #666;"><?= htmlspecialchars($user['email']) ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span style="display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 20px; font-size: 0.85em; <?= $user['role'] === 'admin' ? 'background: #e0e7ff; color: #4338ca;' : 'background: #f1f5f9; color: #64748b;' ?>">
                                <?= ucfirst($user['role'] ?? 'user') ?>
                            </span>
                        </td>
                        <td>
                            <span class="user-status <?= $user['archived'] == 1 ? 'archived' : 'active' ?>">
                                <?= $user['archived'] == 1 ? 'Archived' : 'Active' ?>
                            </span>
                        </td>
                        <td>
                            <div style="color: #4a5568;">
                                <?= date('M d, Y', strtotime($user['created_at'])) ?>
                            </div>
                            <div style="font-size: 0.9em; color: #718096;">
                                <?= date('h:i A', strtotime($user['created_at'])) ?>
                            </div>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>" />
                                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>" />
                                    <select name="new_status" class="action-btn user-status-select" data-user-id="<?= $user['id'] ?>" style="min-width: 100px;">
                                        <option value="active" <?= !$user['archived'] ? 'selected' : '' ?>>Active</option>
                                        <option value="archived" <?= $user['archived'] ? 'selected' : '' ?>>Archive</option>
                                    </select>
                                    <input type="hidden" name="page" value="<?= $currentPage ?>" />
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <!-- Users Pagination -->
            <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php if ($currentPage > 1): ?>
                    <a href="min.php?status=<?= $filterStatus ?>&page=<?= $currentPage - 1 ?>#users-tab" class="page-btn">
                        <i class="fas fa-chevron-left"></i> Previous
                    </a>
                <?php endif; ?>
                
                <?php
                // Show pagination numbers
                $maxLinks = 5;
                $start = max(1, $currentPage - floor($maxLinks / 2));
                $end = min($totalPages, $start + $maxLinks - 1);
                
                // Adjust start if we're near the end
                $start = max(1, min($start, $totalPages - $maxLinks + 1));
                
                // Show first page if we're not starting at 1
                if ($start > 1) {
                    echo '<a href="min.php?status=' . $filterStatus . '&page=1#users-tab" class="page-btn" data-page="1">1</a>';
                    if ($start > 2) echo '<span class="page-btn">...</span>';
                }
                
                // Show page numbers
                for ($i = $start; $i <= $end; $i++): ?>
                    <?php if ($i == $currentPage): ?>
                        <span class="page-btn active" data-page="<?= $i ?>"><?= $i ?></span>
                    <?php else: ?>
                        <a href="min.php?status=<?= $filterStatus ?>&page=<?= $i ?>#users-tab" class="page-btn" data-page="<?= $i ?>"><?= $i ?></a>
                    <?php endif; ?>
                <?php endfor; 
                
                // Show last page if we're not ending at the last page
                    if ($end < $totalPages) {
                    if ($end < $totalPages - 1) echo '<span class="page-btn">...</span>';
                    echo '<a href="min.php?status=' . $filterStatus . '&page=' . $totalPages . '#users-tab" class="page-btn" data-page="' . $totalPages . '">' . $totalPages . '</a>';
                }
                ?>

                <?php if ($currentPage < $totalPages): ?>
                    <a href="min.php?status=<?= $filterStatus ?>&page=<?= $currentPage + 1 ?>#users-tab" class="page-btn" data-page="<?= $currentPage + 1 ?>">
                        Next <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            </div>
        </div>
    </section>
    <section id="comments-tab" class="tab-content">
        <div class="user-controls">
            <div class="search-box">
                <input type="text" id="commentSearch" placeholder="Search comments..." autocomplete="off">
            </div>
            <!-- filter select removed; search will show autocomplete suggestions -->
            <!-- filter removed: search-only UI -->
        </div>
        
        <div class="user-table">
            <table id="commentTable">
                <thead>
                    <tr>
                        <th>User Info</th>
                        <th>Image Name</th>
                        <th>Comment</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($comments as $comment): ?>
                    <tr data-comment-id="<?= (int)$comment['id'] ?>">
                        <td>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 40px; height: 40px; border-radius: 20px; background: #e2e8f0; display: flex; align-items: center; justify-content: center; font-weight: 600; color: #4a5568;">
                                    <?= strtoupper(substr($comment['username'], 0, 1)) ?>
                                </div>
                                <div>
                                    <div style="font-weight: 500;"><?= htmlspecialchars($comment['username']) ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span style="display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 20px; font-size: 0.85em; background: #f1f5f9; color: #64748b;">
                                <?= htmlspecialchars($comment['image_name']) ?>
                            </span>
                        </td>
                        <td>
                            <div style="max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <?= nl2br(htmlspecialchars($comment['comment'])) ?>
                            </div>
                        </td>
                        <td>
                            <div style="color: #4a5568;">
                                <?= date('M d, Y', strtotime($comment['created_at'])) ?>
                            </div>
                            <div style="font-size: 0.9em; color: #718096;">
                                <?= date('h:i A', strtotime($comment['created_at'])) ?>
                            </div>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>" />
                                    <input type="hidden" name="comment_id" value="<?= $comment['id'] ?>" />
                                    <input type="hidden" name="comment_page" value="<?= $currentCommentPage ?>" />
                                    <button type="submit" name="action" value="delete_comment" class="action-btn delete" onclick="return confirm('Do you want to delete this comment?');">
                                        Delete
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($comments)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 40px; color: #666;">
                            No comments found with the selected filter
                        </td>
                    </tr>
                <?php endif; ?>
                    <tr class="no-results" style="display:none;">
                        <td colspan="5" style="text-align:center; padding:20px; color:#666;">No results found</td>
                    </tr>
                </tbody>
            </table>
            <!-- Comments Pagination -->
            <?php if ($totalCommentPages > 1): ?>
            <div class="pagination">
                <?php if ($currentCommentPage > 1): ?>
                    <a href="min.php?comment_status=<?= $commentFilterStatus ?>&comment_page=<?= $currentCommentPage - 1 ?>#comments-tab" class="page-btn" data-page="<?= $currentCommentPage - 1 ?>">
                        <i class="fas fa-chevron-left"></i> Previous
                    </a>
                <?php endif; ?>
                
                <?php
                // Show pagination numbers
                $maxLinks = 5;
                $start = max(1, $currentCommentPage - floor($maxLinks / 2));
                $end = min($totalCommentPages, $start + $maxLinks - 1);
                
                // Adjust start if we're near the end
                $start = max(1, min($start, $totalCommentPages - $maxLinks + 1));
                
                // Show first page if we're not starting at 1
                if ($start > 1) {
                    echo '<a href="min.php?comment_status=' . $commentFilterStatus . '&comment_page=1#comments-tab" class="page-btn">1</a>';
                    if ($start > 2) echo '<span class="page-btn">...</span>';
                }
                
                // Show page numbers
                for ($i = $start; $i <= $end; $i++): ?>
                    <?php if ($i == $currentCommentPage): ?>
                        <span class="page-btn active" data-page="<?= $i ?>"><?= $i ?></span>
                    <?php else: ?>
                        <a href="min.php?comment_status=<?= $commentFilterStatus ?>&comment_page=<?= $i ?>#comments-tab" class="page-btn" data-page="<?= $i ?>"><?= $i ?></a>
                    <?php endif; ?>
                <?php endfor; 
                
                // Show last page if we're not ending at the last page
                    if ($end < $totalCommentPages) {
                    if ($end < $totalCommentPages - 1) echo '<span class="page-btn">...</span>';
                    echo '<a href="min.php?comment_status=' . $commentFilterStatus . '&comment_page=' . $totalCommentPages . '#comments-tab" class="page-btn" data-page="' . $totalCommentPages . '">' . $totalCommentPages . '</a>';
                }
                ?>

                <?php if ($currentCommentPage < $totalCommentPages): ?>
                    <a href="min.php?comment_status=<?= $commentFilterStatus ?>&comment_page=<?= $currentCommentPage + 1 ?>#comments-tab" class="page-btn" data-page="<?= $currentCommentPage + 1 ?>">
                        Next <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <!-- RATINGS SECTION -->
    <section id="ratings-section" class="tab-content">
        <h2><i class="fas fa-star" style="color: #f59e0b; margin-right: 8px;"></i>Ratings</h2>

        <div class="user-controls" style="margin-bottom: 20px; display: flex; gap: 10px; align-items: center;">
            <select id="imageFilter" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 0.95em; background: white; cursor: pointer;">
                <option value="">All Images</option>
                <option value="NGC">NGC</option>
                <option value="BIR">BIR</option>
                <option value="SSS">SSS</option>
                <option value="PhilHealth">PhilHealth</option>
                <option value="CityHealth">CityHealth</option>
            </select>
            <select id="ratingFilter" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 0.95em; background: white; cursor: pointer;">
                <option value="">All Ratings</option>
                <option value="1">★ 1 Star</option>
                <option value="2">★★ 2 Stars</option>
                <option value="3">★★★ 3 Stars</option>
                <option value="4">★★★★ 4 Stars</option>
                <option value="5">★★★★★ 5 Stars</option>
            </select>
        </div>
        <div class="user-table">
            <table id="ratingsTable" style="width: 100%;">
                <thead>
                    <tr>
                        <th>User Info</th>
                        <th>Image Name</th>
                        <th style="text-align: right;">Rating</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($allRatings as $row): ?>
                    <tr data-rating="<?= (int)$row['rating'] ?>" data-image="<?= htmlspecialchars($row['image_name']) ?>">
                        <td>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 40px; height: 40px; border-radius: 20px; background: #e2e8f0; display: flex; align-items: center; justify-content: center; font-weight: 600; color: #4a5568;">
                                    <?= strtoupper(substr($row['username'], 0, 1)) ?>
                                </div>
                                <div>
                                    <div style="font-weight: 500;">
                                        <?= htmlspecialchars($row['username']) ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span style="display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 20px; font-size: 0.85em; background: #f1f5f9; color: #64748b; width: 100%; text-align: left;">
                                <?= htmlspecialchars($row['image_name']) ?>
                            </span>
                        </td>
                        <td style="text-align: right;">
                            <div style="display: flex; align-items: center; gap: 2px; justify-content: flex-end;">
                                <?php for ($i=1; $i<=5; $i++): ?>
                                    <span style="color:<?= $i <= $row['rating'] ? '#f59e0b' : '#e5e7eb' ?>; font-size: 1.2em;">★</span>
                                <?php endfor; ?>
                                <span style="margin-left: 6px; color: #64748b; font-size: 0.95em;">(<?= (int)$row['rating'] ?>)</span>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($allRatings)): ?>
                    <tr>
                        <td colspan="3" style="text-align: center; padding: 40px; color: #666;">
                            No ratings found in the database.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <!-- Ratings Pagination -->
            <?php if ($totalRatingPages > 1): ?>
            <?php 
                // Build filter parameters for pagination links
                $ratingFilterParam = isset($_GET['rating_filter']) && $_GET['rating_filter'] !== '' ? '&rating_filter=' . $_GET['rating_filter'] : '';
                $imageFilterParam = isset($_GET['image_filter']) && $_GET['image_filter'] !== '' ? '&image_filter=' . urlencode($_GET['image_filter']) : '';
                $filterParams = $ratingFilterParam . $imageFilterParam;
            ?>
            <div class="pagination">
                <?php if ($currentRatingPage > 1): ?>
                    <a href="min.php?rating_page=<?= $currentRatingPage - 1 ?><?= $filterParams ?>#ratings-section" class="page-btn" data-page="<?= $currentRatingPage - 1 ?>">
                        <i class="fas fa-chevron-left"></i> Previous
                    </a>
                <?php endif; ?>
                
                <?php
                // Show pagination numbers
                $maxLinks = 5;
                $start = max(1, $currentRatingPage - floor($maxLinks / 2));
                $end = min($totalRatingPages, $start + $maxLinks - 1);
                
                // Adjust start if we're near the end
                $start = max(1, min($start, $totalRatingPages - $maxLinks + 1));
                
                // Show first page if we're not starting at 1
                if ($start > 1) {
                    echo '<a href="min.php?rating_page=1' . $filterParams . '#ratings-section" class="page-btn" data-page="1">1</a>';
                    if ($start > 2) echo '<span class="page-btn">...</span>';
                }
                
                // Show page numbers
                for ($i = $start; $i <= $end; $i++): ?>
                    <?php if ($i == $currentRatingPage): ?>
                        <span class="page-btn active" data-page="<?= $i ?>"><?= $i ?></span>
                    <?php else: ?>
                        <a href="min.php?rating_page=<?= $i ?><?= $filterParams ?>#ratings-section" class="page-btn" data-page="<?= $i ?>"><?= $i ?></a>
                    <?php endif; ?>
                <?php endfor; 
                
                // Show last page if we're not ending at the last page
                    if ($end < $totalRatingPages) {
                    if ($end < $totalRatingPages - 1) echo '<span class="page-btn">...</span>';
                    echo '<a href="min.php?rating_page=' . $totalRatingPages . $filterParams . '#ratings-section" class="page-btn" data-page="' . $totalRatingPages . '">' . $totalRatingPages . '</a>';
                }
                ?>

                <?php if ($currentRatingPage < $totalRatingPages): ?>
                    <a href="min.php?rating_page=<?= $currentRatingPage + 1 ?><?= $filterParams ?>#ratings-section" class="page-btn" data-page="<?= $currentRatingPage + 1 ?>">
                        Next <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>
<script>
    // Tab functionality with persistence
    document.addEventListener('DOMContentLoaded', function() {
        const tabButtons = document.querySelectorAll('.tab-button');
        const tabContents = document.querySelectorAll('.tab-content');
        
        // Function to activate a tab
        function activateTab(tabId) {
            tabButtons.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            const button = document.querySelector(`.tab-button[data-tab="${tabId}"]`);
            const content = document.getElementById(tabId);
            
            if (button && content) {
                button.classList.add('active');
                content.classList.add('active');
            } else {
                // Default to dashboard if invalid tab
                document.querySelector('.tab-button[data-tab="Dashboard-tab"]').classList.add('active');
                document.getElementById('Dashboard-tab').classList.add('active');
            }
        }
        
        // Check URL hash first
        const hash = window.location.hash.substring(1);
        if (hash && document.getElementById(hash)) {
            activateTab(hash);
        } else {
            // Check sessionStorage
            const savedTab = sessionStorage.getItem('activeTab');
            if (savedTab) {
                activateTab(savedTab);
            } else {
                // Default to dashboard
                activateTab('Dashboard-tab');
            }
        }
        
        // Set up tab click handlers
        tabButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const tabId = btn.dataset.tab;
                sessionStorage.setItem('activeTab', tabId);
                activateTab(tabId);
            });
        });

        // Sidebar profile dropdown toggle
        const sidebarProfileDropdown = document.querySelector('.sidebar .profile-dropdown');
        if (sidebarProfileDropdown) {
            const sidebarProfileBtn = sidebarProfileDropdown.querySelector('.sidebar-profile-btn');
            function closeSidebarProfile(){ sidebarProfileDropdown.classList.remove('open'); }
            sidebarProfileBtn.addEventListener('click', function(e){
                e.stopPropagation();
                sidebarProfileDropdown.classList.toggle('open');
            });
            document.addEventListener('click', function(e){
                if (!sidebarProfileDropdown.contains(e.target)) closeSidebarProfile();
            });
            document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeSidebarProfile(); });
        }
        
        // Set active tab in forms
        document.querySelectorAll('form').forEach(form => {
            // Add hidden input for active tab if it doesn't exist
            if (!form.querySelector('input[name="active_tab"]')) {
                const activeTab = document.querySelector('.tab-content.active').id;
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'active_tab';
                input.value = activeTab;
                form.appendChild(input);
            }
            
            form.addEventListener('submit', function() {
                const activeTab = document.querySelector('.tab-content.active').id;
                sessionStorage.setItem('activeTab', activeTab);
            });
        });

        // Admin form toggle and validation
        const showAdminFormBtn = document.getElementById('showAdminForm');
        const adminForm = document.getElementById('adminForm');
        const cancelAdminFormBtn = document.getElementById('cancelAdminForm');
        const usernameInput = document.getElementById('username');
        const emailInput = document.getElementById('email');
        const usernameStatus = document.getElementById('usernameStatus');
        const emailStatus = document.getElementById('emailStatus');
        const adminFormWarning = document.getElementById('adminFormWarning');
        const submitAdminBtn = document.getElementById('submitAdminBtn');
        const createAdminForm = document.getElementById('createAdminForm');
        
        if (showAdminFormBtn && adminForm && cancelAdminFormBtn) {
            showAdminFormBtn.addEventListener('click', () => {
                adminForm.classList.add('active');
                showAdminFormBtn.style.display = 'none';
                // Clear previous status
                usernameStatus.innerHTML = '';
                emailStatus.innerHTML = '';
                submitAdminBtn.disabled = false;
                adminFormWarning.style.display = 'none';
            });
            
            cancelAdminFormBtn.addEventListener('click', () => {
                adminForm.classList.remove('active');
                showAdminFormBtn.style.display = 'block';
            });
        }
        
        // Check username availability
        if (usernameInput) {
            usernameInput.addEventListener('blur', async function() {
                const username = this.value.trim();
                if (username.length > 0) {
                    try {
                        const response = await fetch('check_username.php?username=' + encodeURIComponent(username));
                        const result = await response.json();
                        if (result.exists) {
                            usernameStatus.innerHTML = '⚠️ Username already taken';
                            usernameStatus.style.color = '#dc2626';
                            submitAdminBtn.disabled = true;
                        } else {
                            usernameStatus.innerHTML = '✓ Available';
                            usernameStatus.style.color = '#16a34a';
                            checkFormValidity();
                        }
                    } catch (error) {
                        console.error('Error checking username:', error);
                    }
                } else {
                    usernameStatus.innerHTML = '';
                }
            });
        }
        
        // Check email availability
        if (emailInput) {
            emailInput.addEventListener('blur', async function() {
                const email = this.value.trim();
                if (email.length > 0) {
                    try {
                        const response = await fetch('check_email.php?email=' + encodeURIComponent(email));
                        const result = await response.json();
                        if (result.exists) {
                            emailStatus.innerHTML = '⚠️ Email already exists';
                            emailStatus.style.color = '#dc2626';
                            submitAdminBtn.disabled = true;
                        } else {
                            emailStatus.innerHTML = '✓ Available';
                            emailStatus.style.color = '#16a34a';
                            checkFormValidity();
                        }
                    } catch (error) {
                        console.error('Error checking email:', error);
                    }
                } else {
                    emailStatus.innerHTML = '';
                }
            });
        }
        
        // Check form validity
        function checkFormValidity() {
            const usernameTaken = usernameStatus.textContent.includes('already taken');
            const emailTaken = emailStatus.textContent.includes('already exists');
            if (!usernameTaken && !emailTaken) {
                submitAdminBtn.disabled = false;
            }
        }
        
        // Prevent form submission if duplicates detected
        if (createAdminForm) {
            createAdminForm.addEventListener('submit', function(e) {
                const usernameTaken = usernameStatus.textContent.includes('already taken');
                const emailTaken = emailStatus.textContent.includes('already exists');
                if (usernameTaken || emailTaken) {
                    e.preventDefault();
                    adminFormWarning.textContent = usernameTaken ? '⚠️ Username already taken!' : '⚠️ Email already exists!';
                    adminFormWarning.style.display = 'block';
                    return false;
                }
            });
        }

        // Chart.js
        const ctx = document.getElementById('userChart').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($monthLabels) ?>,
                datasets: [{
                    label: 'User registrations',
                    data: <?= json_encode($monthPercentages) ?>,
                    backgroundColor: function(context) {
                        const i = context.dataIndex;
                        const base = 'rgba(37,99,235,'; // blue
                        return base + (0.65 - (i % 3) * 0.08) + ')';
                    },
                    borderColor: 'rgba(15,76,129,0.12)',
                    borderRadius: 6,
                    borderSkipped: false,
                    barThickness: 'flex'
                }]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        enabled: true,
                        backgroundColor: 'rgba(17,24,39,0.95)',
                        titleColor: '#fff',
                        bodyColor: '#e6eef8',
                        padding: 10,
                        cornerRadius: 6,
                        xPadding: 10,
                        yPadding: 8,
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { color: '#334155' }
                    },
                    y: {
                        beginAtZero: true,
                        suggestedMax: 100,
                        grid: {
                            color: 'rgba(15, 23, 42, 0.05)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#334155',
                            callback: function(value) { return value + '%'; }
                        }
                    }
                },
                onClick: (evt, elements) => {
                    const points = chart.getElementsAtEventForMode(evt, 'nearest', { intersect: true }, false);
                    if (!points.length) return;

                    const point = points[0];
                    const monthIndex = point.index;

                    // Build popup content from server-side arrays
                    const month = <?= json_encode($monthLabels) ?>[monthIndex];
                    const totalUsers = <?= json_encode($monthCountsRaw) ?>[monthIndex];
                    const totalComments = <?= json_encode($monthCommentsCounts) ?>[monthIndex];
                    const top5 = <?= json_encode($topImagesPerMonth) ?>[monthIndex] || [];
                    const latestComment = <?= json_encode($latestComments) ?>[monthIndex] || 'No comments';

                    // Remove existing card
                    document.querySelectorAll('.chart-card').forEach(n => n.remove());

                    const canvasRect = ctx.canvas.getBoundingClientRect();
                    const bar = point.element;
                    // Calculate position relative to viewport
                    const x = bar.x + canvasRect.left;
                    const y = bar.y + canvasRect.top - 10;

                    const card = document.createElement('div');
                    card.className = 'chart-card';
                    
                    // Remove any existing cards with fade out
                    document.querySelectorAll('.chart-card').forEach(oldCard => {
                        oldCard.classList.remove('visible');
                        setTimeout(() => oldCard.remove(), 200);
                    });

                    // Position card and ensure it stays within viewport bounds
                    document.body.appendChild(card);
                    
                    // Calculate final position
                    let finalX = x + 8;
                    let finalY = y - card.offsetHeight - 16;
                    
                    // Adjust if card would go off screen
                    if (finalX + card.offsetWidth > window.innerWidth) {
                        finalX = window.innerWidth - card.offsetWidth - 16;
                    }
                    if (finalY < 0) {
                        finalY = y + 32; // Show below the bar instead
                        card.classList.add('reverse');
                    }
                    
                    card.style.left = finalX + 'px';
                    card.style.top = finalY + 'px';

                    let topHtml = '';
                    if (top5.length) {
                        topHtml = '<div class="top-images">';
                        top5.forEach(item => {
                            const imgTag = item.thumb ? `<img src="${item.thumb}" alt="${item.image}">` : `<div style="width:40px;height:40px;background:#eee;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:11px;color:#666;">img</div>`;
                            topHtml += `<div class="item">${imgTag}<div class="meta">${item.image || 'Unnamed'}<br><small>${item.count} comments</small></div></div>`;
                        });
                        topHtml += '</div>';
                    } else {
                        topHtml = '<p style="margin:6px 0;">No image comments</p>';
                    }

                    card.innerHTML = `
                        <h4>${month}</h4>
                        <p><strong>Users:</strong> ${totalUsers}</p>
                        <p><strong>Comments:</strong> ${totalComments}</p>
                        <div><strong>Top images:</strong> ${topHtml}</div>
                        <p style="margin-top:8px;"><strong>Latest:</strong> ${latestComment}</p>
                    `;
                    document.body.appendChild(card);
                    
                    // Add click handler to close card when clicking outside
                    function closeCard(e) {
                        if (!card.contains(e.target)) {
                            card.classList.remove('visible');
                            setTimeout(() => {
                                card.remove();
                                document.removeEventListener('click', closeCard);
                            }, 200);
                        }
                    }
                    
                    // Delay adding the visible class for animation
                    requestAnimationFrame(() => {
                        card.classList.add('visible');
                    });
                    
                    // Add click listener with a slight delay to prevent immediate closing
                    setTimeout(() => {
                        document.addEventListener('click', closeCard);
                    }, 100);
                }
            }
        });
        // --- Client-side user filtering (search + status) ---
        (function(){
            const userSearch = document.getElementById('userSearch');
            const userStatusFilter = document.getElementById('userStatusFilter');
            const usersTable = document.getElementById('usersTable');
            if (!usersTable) return;

            function debounce(fn, ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a), ms); }; }

            function applyUserFilter(){
                const q = userSearch ? userSearch.value.toLowerCase().trim() : '';
                const status = userStatusFilter ? userStatusFilter.value : 'all';
                const rows = usersTable.querySelectorAll('tbody tr');
                let any = false;
                rows.forEach(r => {
                    if (r.classList.contains('no-results')) return;
                    const archived = r.getAttribute('data-archived') === '1';
                    let statusMatch = (status === 'all') || (status === 'active' && !archived) || (status === 'archived' && archived);
                    let textMatch = q === '' ? true : r.textContent.toLowerCase().includes(q);
                    const show = statusMatch && textMatch;
                    r.style.display = show ? '' : 'none';
                    if (show) any = true;
                });
                const noRow = usersTable.querySelector('tbody tr.no-results');
                if (noRow) noRow.style.display = any ? 'none' : '';
            }

            // Live user suggestions + automatic AJAX search-on-type (no Enter required)
            if (userSearch) {
                // create suggestion dropdown for users
                const userSuggestBox = document.createElement('div');
                userSuggestBox.className = 'user-suggestions';
                userSuggestBox.style.position = 'absolute';
                userSuggestBox.style.zIndex = 1300;
                userSuggestBox.style.background = '#fff';
                userSuggestBox.style.border = '1px solid rgba(0,0,0,0.08)';
                userSuggestBox.style.boxShadow = '0 2px 6px rgba(0,0,0,0.08)';
                userSuggestBox.style.display = 'none';
                userSuggestBox.style.maxHeight = '260px';
                userSuggestBox.style.overflowY = 'auto';
                const userSearchContainer = document.querySelector('#users-tab .search-box');
                if (userSearchContainer) userSearchContainer.appendChild(userSuggestBox);

                async function fetchUserSuggestions(q) {
                    if (!q) return [];
                    try {
                        const res = await fetch('get_suggestions.php?q=' + encodeURIComponent(q));
                        if (!res.ok) return [];
                        const data = await res.json();
                        return Array.isArray(data) ? data.filter(i => i.type === 'user') : [];
                    } catch (e) { return []; }
                }

                function showUserSuggestions(items, q) {
                    userSuggestBox.innerHTML = '';
                    if (!items || items.length === 0) { userSuggestBox.style.display = 'none'; return; }
                    items.forEach(it => {
                        const el = document.createElement('div');
                        el.className = 'suggest-item';
                        const t = it.text || '';
                        const idx = t.toLowerCase().indexOf(q.toLowerCase());
                        if (idx >= 0) {
                            const before = t.slice(0, idx);
                            const match = t.slice(idx, idx + q.length);
                            const after = t.slice(idx + q.length);
                            el.innerHTML = `${before}<strong>${match}</strong>${after}`;
                        } else el.textContent = t;
                        el.style.padding = '8px 12px';
                        el.style.cursor = 'pointer';
                        el.addEventListener('click', function(){
                            userSearch.value = it.text;
                            // run AJAX search for this username and inject rows
                            fetchAndInjectUsers(it.text);
                            userSuggestBox.style.display = 'none';
                        });
                        userSuggestBox.appendChild(el);
                    });
                    userSuggestBox.style.display = 'block';
                }

                async function fetchAndInjectUsers(q, page = 1) {
                    const s = userStatusFilter ? userStatusFilter.value : 'all';
                    try {
                        const res = await fetch('user_search.php?q=' + encodeURIComponent(q) + '&status=' + encodeURIComponent(s) + '&page=' + encodeURIComponent(page));
                        if (!res.ok) return;
                        const obj = await res.json();
                        const tbody = document.querySelector('#usersTable tbody');
                        if (tbody) tbody.innerHTML = obj.html || '';
                        // inject pagination if provided (user_search.php may return pagination html)
                        const pag = document.querySelector('#usersTable').parentElement.querySelector('.pagination');
                        if (pag) {
                            // only replace pagination if server returned a non-empty pagination block;
                            // otherwise preserve the existing pagination rendered on the page
                            if (obj.pagination && obj.pagination.toString().trim() !== '') {
                                pag.innerHTML = obj.pagination;
                            }
                        }
                        // ensure pagination links include the current status filter
                        try { if (typeof updatePaginationLinksWithStatus === 'function') updatePaginationLinksWithStatus(s); } catch(e) {}
                        // ensure the active page button is highlighted (blue)
                        try { setActivePaginationButton(page); } catch(e) {}
                        // update URL
                        try {
                            const u = new URL(window.location.href);
                            u.searchParams.set('status', s);
                            u.searchParams.set('search', q);
                            u.searchParams.set('page', 1);
                            history.replaceState(null, '', u.toString());
                        } catch (e) {}
                    } catch (e) {}
                }

                // Helper: set the active pagination button in the users pagination container
                function setActivePaginationButton(page) {
                    const pag = document.querySelector('#usersTable').parentElement.querySelector('.pagination');
                    if (!pag) return;
                    // remove any existing active classes
                    pag.querySelectorAll('.page-btn').forEach(el => el.classList.remove('active'));
                    // try find element by data-page attribute first
                    let target = pag.querySelector('.page-btn[data-page="' + page + '"]');
                    if (!target) {
                        // fallback: look for anchors/spans whose text equals the page or whose href contains page=page
                        const items = Array.from(pag.querySelectorAll('.page-btn'));
                        for (const it of items) {
                            const txt = it.textContent.trim();
                            if (txt === String(page)) { target = it; break; }
                            const href = it.getAttribute && it.getAttribute('href');
                            if (href) {
                                try {
                                    const u = new URL(href, window.location.href);
                                    const pval = u.searchParams.get('page') || u.searchParams.get('comment_page') || u.searchParams.get('user_page');
                                                                       if (pval && parseInt(pval) === parseInt(page)) { target = it; break; }
                                } catch (e) {}
                            }
                        }
                    }
                    if (target) target.classList.add('active');
                }

                userSearch.addEventListener('input', debounce(async function(){
                    const q = userSearch.value.trim();
                    // show suggestions
                    const items = await fetchUserSuggestions(q);
                    showUserSuggestions(items, q);
                    // automatically inject matching rows (AJAX) without requiring Enter
                    fetchAndInjectUsers(q, 1);
                }, 260));

                userSearch.addEventListener('keydown', function(e){
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        const q = userSearch.value.trim();
                        fetchAndInjectUsers(q);
                        userSuggestBox.style.display = 'none';
                    }
                });

                // hide suggestions on blur
                userSearch.addEventListener('blur', function(){ setTimeout(()=> userSuggestBox.style.display='none', 160); });

                // Delegated pagination handler for users: intercept clicks on pagination links
                // that appear on page load or after AJAX injection and load via fetchAndInjectUsers.
                document.addEventListener('click', function(e) {
                    const a = e.target.closest && e.target.closest('.pagination a');
                    if (!a) return;
                    const usersTab = document.getElementById('users-tab');
                    if (!usersTab || !usersTab.contains(a)) return; // only handle user pagination
                    e.preventDefault();
                    let p = parseInt(a.getAttribute('data-page')) || NaN;
                    if (!p) {
                        try {
                            const href = a.getAttribute('href') || '';
                            const u = new URL(href, window.location.href);
                            p = parseInt(u.searchParams.get('page')) || 1;
                        } catch (err) { p = 1; }
                    }
                    const q = userSearch ? userSearch.value.trim() : '';
                    fetchAndInjectUsers(q, p);
                });
            }
            if (userStatusFilter) userStatusFilter.addEventListener('change', function(){
                const val = this.value;
                const q = userSearch ? userSearch.value.trim() : '';
                window.location.href = 'min.php?status=' + encodeURIComponent(val) + '&search=' + encodeURIComponent(q) + '&page=1#users-tab';
            });
            // initial
            applyUserFilter();
        })();
    });

    // Client-side user filtering by status + search
    const userSearch = document.getElementById('userSearch');
    const userStatusFilter = document.getElementById('userStatusFilter');
    const usersTable = document.getElementById('usersTable');

    function applyUserFilters() {
        const q = (userSearch ? userSearch.value.toLowerCase().trim() : '');
        // prefer the select value; if missing, fall back to URL param or 'all'
        let status = 'all';
        if (userStatusFilter && userStatusFilter.value) status = userStatusFilter.value;
        else {
            try { const p = new URLSearchParams(window.location.search); status = p.get('status') || 'all'; } catch(e){}
        }
        const rows = usersTable ? usersTable.querySelectorAll('tbody tr') : [];
        rows.forEach(row => {
            if (row.classList.contains('no-results')) return;
            const txt = row.textContent.toLowerCase();
            // prefer explicit data-archived attribute
            const attr = row.getAttribute('data-archived');
            const isArchived = attr === '1';
            const statusMatch = (status === 'all') || (status === 'active' && !isArchived) || (status === 'archived' && isArchived);
            const textMatch = q === '' || txt.includes(q);
            row.style.display = (statusMatch && textMatch) ? '' : 'none';
        });
    }

    // Debounce helper
    function debounce(fn, ms) {
        let t;
        return function(...args) {
            clearTimeout(t);
            t = setTimeout(() => fn.apply(this, args), ms);
        }
    }

    // Record previous value on focus so we can revert if user cancels the confirmation
    document.addEventListener('focusin', function(e) {
        const el = e.target;
        if (el && el.classList && el.classList.contains('user-status-select')) {
            el.dataset.prevStatus = el.value;
        }
    });

    if (userSearch) userSearch.addEventListener('input', debounce(applyUserFilters, 150));
    function updatePaginationLinksWithStatus(status) {
        if (!usersTable) return;
        const pagContainer = usersTable.parentElement.querySelector('.pagination');
        if (!pagContainer) return;
        const links = pagContainer.querySelectorAll('a');
        links.forEach(a => {
            try {
                const u = new URL(a.getAttribute('href'), window.location.href);
                u.searchParams.set('status', status);
                a.setAttribute('href', u.toString());
            } catch (e) {}
        });
    }

    if (userStatusFilter) {
        userStatusFilter.addEventListener('change', function(){
            const val = this.value;
            window.location.href = 'min.php?status=' + encodeURIComponent(val) + '&page=1#users-tab';
        });
        // ensure pagination links match initial state
        updatePaginationLinksWithStatus(userStatusFilter.value);
    }
    // initial apply
    applyUserFilters();
    // AJAX handler for inline user status selects to avoid page jumps
    document.addEventListener('change', function(e){
        const el = e.target;
        if (el && el.classList && el.classList.contains('user-status-select')) {
            const userId = el.getAttribute('data-user-id');
            const newStatus = el.value;
            const prevStatus = el.dataset.prevStatus || (newStatus === 'archived' ? 'active' : 'archived');
            // confirmation message
            const confirmMsg = newStatus === 'archived' ? 'Are you sure you want to archive this user?' : 'Are you sure you want to activate this user?';
            if (!confirm(confirmMsg)) {
                // user cancelled - revert select value
                el.value = prevStatus;
                return;
            }
            const csrf = '<?= isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : '' ?>';
            // optimistic update: change badge text and data-archived attribute
            const row = el.closest('tr');
            if (row) {
                row.setAttribute('data-archived', newStatus === 'archived' ? '1' : '0');
                const badge = row.querySelector('.user-status');
                if (badge) {
                    badge.textContent = newStatus === 'archived' ? 'Archived' : 'Active';
                    badge.classList.toggle('archived', newStatus === 'archived');
                    badge.classList.toggle('active', newStatus !== 'archived');
                }
            }
            // send ajax
            fetch('user_status_ajax.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'csrf_token=' + encodeURIComponent(csrf) + '&user_id=' + encodeURIComponent(userId) + '&new_status=' + encodeURIComponent(newStatus)
            }).then(r=>r.json()).then(j=>{
                if (!j.ok) {
                    // revert UI if failed
                    if (row) {
                        row.setAttribute('data-archived', newStatus === 'archived' ? '0' : '1');
                        const badge = row.querySelector('.user-status');
                        if (badge) {
                            badge.textContent = newStatus === 'archived' ? 'Active' : 'Archived';
                            badge.classList.toggle('archived', newStatus !== 'archived');
                            badge.classList.toggle('active', newStatus === 'archived');
                        }
                        // also revert the select UI
                        const select = row.querySelector('.user-status-select');
                        if (select) select.value = prevStatus;
                    }
                    alert('Update failed');
                }
            }).catch(()=>{ alert('Network error'); });
        }
    });
    // Comment search with filter
    const commentSearch = document.getElementById('commentSearch');
    const commentFilterBy = document.getElementById('commentFilterBy');
    function filterComments() {
        const filter = commentSearch.value.toLowerCase();
        const by = commentFilterBy ? commentFilterBy.value : 'all';
        const rows = document.querySelectorAll('#commentTable tbody tr');
        let anyVisible = false;
        rows.forEach(row => {
            // columns: 0=user,1=image,2=comment
            const cells = row.querySelectorAll('td');
            let hay = '';
            if (by === 'user') hay = (cells[0] ? cells[0].textContent : '').toLowerCase();
            else if (by === 'image') hay = (cells[1] ? cells[1].textContent : '').toLowerCase();
            else if (by === 'comment') hay = (cells[2] ? cells[2].textContent : '').toLowerCase();
            else hay = row.textContent.toLowerCase();
            const show = hay.includes(filter);
            row.style.display = show ? '' : 'none';
            if (show) anyVisible = true;
        });
        const noRow = document.querySelector('#commentTable tbody tr.no-results');
        if (noRow) noRow.style.display = anyVisible ? 'none' : '';
    }

    if (commentSearch) commentSearch.addEventListener('input', filterComments);
    // Autocomplete suggestions
    const suggestionBox = document.createElement('div');
    suggestionBox.className = 'comment-suggestions';
    suggestionBox.style.position = 'absolute';
    suggestionBox.style.zIndex = 1200;
    suggestionBox.style.background = '#fff';
    suggestionBox.style.border = '1px solid rgba(0,0,0,0.08)';
    suggestionBox.style.boxShadow = '0 2px 6px rgba(0,0,0,0.08)';
    suggestionBox.style.display = 'none';
    suggestionBox.style.maxHeight = '240px';
    suggestionBox.style.overflowY = 'auto';
    document.querySelector('#comments-tab .search-box').appendChild(suggestionBox);

    // Levenshtein distance for fuzzy matching
    function levenshtein(a, b) {
        if (!a.length) return b.length;
        if (!b.length) return a.length;
        a = a.toLowerCase(); b = b.toLowerCase();
        const matrix = Array.from({length: b.length + 1}, (_, i) => [i]);
        for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
        for (let i = 1; i <= b.length; i++){
            for (let j = 1; j <= a.length; j++){
                if (b[i-1] === a[j-1]) matrix[i][j] = matrix[i-1][j-1];
                else matrix[i][j] = Math.min(matrix[i-1][j-1]+1, matrix[i][j-1]+1, matrix[i-1][j]+1);
            }
        }
        return matrix[b.length][a.length];
    }

    function buildSuggestions() {
        const rows = Array.from(document.querySelectorAll('#commentTable tbody tr'))
            .filter(r => !r.classList.contains('no-results'));
        const terms = new Set();
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells[0]) terms.add(cells[0].textContent.trim());
            if (cells[1]) terms.add(cells[1].textContent.trim());
            if (cells[2]) {
                const txt = cells[2].textContent.trim();
                if (txt) terms.add(txt.slice(0, 160));
            }
        });
        return Array.from(terms).filter(t => t.length > 0);
    }

    function getScoredTerms(query){
        const q = query.trim().toLowerCase();
        if (!q) return [];
        const terms = buildSuggestions();
        const scored = terms.map(term => {
            const t = term.toLowerCase();
            let score = 9999;
            if (t === q) score = 0;
            else if (t.startsWith(q)) score = 1;
            else if (t.includes(q)) score = 2;
            else score = levenshtein(q, t);
            return {term, score};
        });
        // keep reasonably close matches: allow some fuzz depending on length
        const maxAllowed = s => Math.max(2, Math.floor(s.length * 0.45));
        const filtered = scored.filter(s => s.score <= maxAllowed(s.term));
        filtered.sort((a,b)=> a.score - b.score);
        return filtered.slice(0, 10).map(s => s.term);
    }

    let suggestTimer = null;
    async function fetchSuggestions(query) {
        try {
            const res = await fetch('get_suggestions.php?q=' + encodeURIComponent(query));
            if (!res.ok) return [];
            const data = await res.json();
            return Array.isArray(data) ? data : [];
        } catch (e) { return []; }
    }

    function showServerSuggestions(items, query) {
        suggestionBox.innerHTML = '';
        if (!items || items.length === 0) { suggestionBox.style.display = 'none'; return; }
        // group by type and render label
        const groupBy = {};
        items.forEach(it => { (groupBy[it.type] = groupBy[it.type] || []).push(it); });
       
        order.forEach(type => {
            if (!groupBy[type]) return;
            const header = document.createElement('div');
            header.className = 'suggest-header';
            header.style.padding = '6px 10px';
            header.style.fontSize = '12px';
            header.style.color = '#666';
            header.textContent = type === 'user' ? 'Users' : (type === 'image' ? 'Images' : 'Comments');
            suggestionBox.appendChild(header);
            groupBy[type].forEach(itemData => {
                const item = document.createElement('div');
                item.className = 'suggest-item';
                // highlight match
                const t = itemData.text;
                const idx = t.toLowerCase().indexOf(query.toLowerCase());
                if (idx >= 0) {
                    const before = t.slice(0, idx);
                    const match = t.slice(idx, idx + query.length);
                    const after = t.slice(idx + query.length);
                    item.innerHTML = `${before}<strong>${match}</strong>${after}`;
                } else item.textContent = t;
                item.style.padding = '8px 12px';
                item.style.cursor = 'pointer';
                item.addEventListener('click', function() {
                    // if user suggestion, fill and filter comments by that username
                    if (itemData.type === 'user') {
                        commentSearch.value = itemData.text;
                        filterComments();
                        suggestionBox.style.display = 'none';
                        // optionally jump to comments tab
                        const tabBtn = document.querySelector('.tab-button[data-tab="comments-tab"]');
                        if (tabBtn) { tabBtn.click(); }
                    } else if (itemData.type === 'image') {
                        commentSearch.value = itemData.text;
                        filterComments();
                        suggestionBox.style.display = 'none';
                    } else {
                        commentSearch.value = itemData.text;
                        filterComments();
                        suggestionBox.style.display = 'none';
                    }
                });
                suggestionBox.appendChild(item);
            });
        });
        suggestionBox.style.display = 'block';
    }

    // Comment search: live suggestions + server-backed results (AJAX) with pagination injection
    async function fetchAndInjectComments(q, page=1) {
        try {
            const res = await fetch('comment_search.php?q=' + encodeURIComponent(q) + '&page=' + encodeURIComponent(page));
            if (!res.ok) return;
            const obj = await res.json();
            const tbody = document.querySelector('#commentTable tbody');
            if (tbody) tbody.innerHTML = obj.html || '';
            // inject pagination into the nearest .pagination after the comment table
            const pagContainer = document.querySelector('#commentTable').parentElement.querySelector('.pagination');
            if (pagContainer) pagContainer.innerHTML = obj.pagination || '';
            // attach handlers to new pagination links (handle both data-page and href-based links)
            if (pagContainer) {
                const anchors = pagContainer.querySelectorAll('a');
                anchors.forEach(a => {
                    a.style.cursor = 'pointer';
                    a.addEventListener('click', function(e){
                        e.preventDefault();
                        // try data-page first
                        let p = parseInt(this.getAttribute('data-page')) || NaN;
                        if (!p) {
                            // try to parse from href query (comment_page= or page=)
                            try {
                                const href = this.getAttribute('href') || '';
                                const u = new URL(href, window.location.href);
                                p = parseInt(u.searchParams.get('comment_page') || u.searchParams.get('page')) || 1;
                            } catch (err) {
                                p = 1;
                            }
                        }
                        fetchAndInjectComments(q, p);
                    });
                });
            }
        } catch (e) {}
    }

    commentSearch.addEventListener('input', function(){
        filterComments();
        const q = commentSearch.value.trim();
        if (suggestTimer) clearTimeout(suggestTimer);
        if (!q) { suggestionBox.style.display='none';
            // if empty, reload initial page fragment (first page comments)
            fetchAndInjectComments('');
            return; }
        suggestTimer = setTimeout(async () => {
            const items = await fetchSuggestions(q);
            showServerSuggestions(items, q);
            // also fetch server-side matching comments and inject first page
            fetchAndInjectComments(q, 1);
        }, 180);
    });

    // Delegated pagination handler: catches clicks on pagination links even if they
    // were rendered on page load (server-side) or injected later. This prevents
    // the need to perform a prior search before pagination works.
    document.addEventListener('click', function(e) {
        const a = e.target.closest && e.target.closest('.pagination a');
        if (!a) return;
        // Only handle links inside the comments area
        const pagParent = a.closest('.pagination');
        if (!pagParent) return;
        // Prevent default navigation
        e.preventDefault();
        // Determine target page: prefer data-page, fallback to query param in href
        let p = parseInt(a.getAttribute('data-page')) || NaN;
        if (!p) {
            try {
                const href = a.getAttribute('href') || '';
                const u = new URL(href, window.location.href);
                p = parseInt(u.searchParams.get('comment_page') || u.searchParams.get('page')) || 1;
            } catch (err) {
                p = 1;
            }
        }
        // use current search box value as query
        const q = (commentSearch && commentSearch.value) ? commentSearch.value.trim() : '';
        // Fetch and inject the requested page
        fetchAndInjectComments(q, p);
    });
 
    // Image stats click handler: clicking an image stat opens the Comments tab and
    // injects all comments for that image name using existing fetchAndInjectComments.
    document.addEventListener('click', function(e) {
        const item = e.target.closest && e.target.closest('.image-stat-item[data-image]');
        if (!item) return;
        e.preventDefault();
        const imageName = item.getAttribute('data-image') || '';
        if (!imageName) return;
        // set search input value
        const commentInput = document.getElementById('commentSearch');
        if (commentInput) commentInput.value = imageName;
        // activate comments tab
        const tabBtn = document.querySelector('.tab-button[data-tab="comments-tab"]');
        if (tabBtn) tabBtn.click();
        // fetch comments for this image
        if (typeof fetchAndInjectComments === 'function') {
            fetchAndInjectComments(imageName, 1);
        } else {
            try {
                const u = new URL(window.location.href);
                u.searchParams.set('search', imageName);
                u.searchParams.set('comment_page', 1);
                window.location.href = u.toString() + '#comments-tab';
            } catch (err) { }
        }
    });

    // Rating card click handler: clicking a rating card opens the Ratings tab
    // and filters by that image name
    document.addEventListener('click', function(e) {
        const cardBtn = e.target.closest && e.target.closest('.rating-card-btn[data-image]');
        if (!cardBtn) return;
        e.preventDefault();
        const imageName = cardBtn.getAttribute('data-image') || '';
        if (!imageName) return;
        // activate ratings tab
        const tabBtn = document.querySelector('.tab-button[data-tab="ratings-section"]');
        if (tabBtn) tabBtn.click();
        // scroll to ratings section
        setTimeout(() => {
            const ratingsSection = document.getElementById('ratings-section');
            if (ratingsSection) {
                ratingsSection.scrollIntoView({ behavior: 'smooth' });
            }
        }, 100);
    });

    // Star filter button click handler
    document.addEventListener('click', function(e) {
        const starBtn = e.target.closest && e.target.closest('.star-filter-btn');
        if (!starBtn) return;
        
        e.preventDefault();
        const rating = starBtn.getAttribute('data-rating');
        const imageName = starBtn.getAttribute('data-image');
        
        if (rating && imageName) {
            // Store both image name and rating filter in localStorage
            localStorage.setItem('ratingFilterValue', rating);
            localStorage.setItem('ratingImageFilter', imageName);
            
            // Set the image filter dropdown to the selected image
            const imageFilter = document.getElementById('imageFilter');
            if (imageFilter) {
                imageFilter.value = imageName;
            }
            
            // Go to page 1 with both filters in URL
            window.location.href = 'min.php?rating_page=1&rating_filter=' + rating + '&image_filter=' + encodeURIComponent(imageName) + '#ratings-section';
        }
    });

    // Ratings filter functionality
    const ratingFilter = document.getElementById('ratingFilter');
    const imageFilter = document.getElementById('imageFilter');
    const ratingsTable = document.getElementById('ratingsTable');
    
    if (ratingFilter && ratingsTable) {
        // Restore filter values from localStorage when page loads
        const savedRatingFilter = localStorage.getItem('ratingFilterValue');
        const savedImageFilter = localStorage.getItem('ratingImageFilter');
        
        if (savedRatingFilter) {
            ratingFilter.value = savedRatingFilter;
        }
        if (savedImageFilter && imageFilter) {
            imageFilter.value = savedImageFilter;
        }
        
        // Apply the filter immediately
        applyRatingFilter();

        ratingFilter.addEventListener('change', function() {
            // Save filter value to localStorage
            localStorage.setItem('ratingFilterValue', this.value);
            applyRatingFilter();
            // Go back to page 1 when filter changes, include both filters in URL
            const ratingParam = this.value ? '&rating_filter=' + this.value : '';
            const imageParam = imageFilter && imageFilter.value ? '&image_filter=' + encodeURIComponent(imageFilter.value) : '';
            window.location.href = 'min.php?rating_page=1' + ratingParam + imageParam + '#ratings-section';
        });

        if (imageFilter) {
            imageFilter.addEventListener('change', function() {
                // Save filter value to localStorage
                localStorage.setItem('ratingImageFilter', this.value);
                applyRatingFilter();
                // Go back to page 1 when filter changes, include both filters in URL
                const imageParam = this.value ? '&image_filter=' + encodeURIComponent(this.value) : '';
                const ratingParam = ratingFilter.value ? '&rating_filter=' + ratingFilter.value : '';
                window.location.href = 'min.php?rating_page=1' + ratingParam + imageParam + '#ratings-section';
            });
        }

        function applyRatingFilter() {
            const selectedRating = ratingFilter.value;
            const selectedImage = imageFilter ? imageFilter.value : '';
            const rows = ratingsTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const rowRating = String(row.getAttribute('data-rating'));
                const rowImage = row.getAttribute('data-image');
                
                // Check if rating matches (convert both to string for comparison)
                const ratingMatch = !selectedRating || rowRating === String(selectedRating);
                
                // Check if image matches (if an image filter is set)
                const imageMatch = !selectedImage || rowImage === selectedImage;
                
                // Show row if both conditions match
                row.style.display = (ratingMatch && imageMatch) ? '' : 'none';
            });
        }
    }

    // Ratings Pagination Handler
    document.addEventListener('click', function(e) {
        const paginationLink = e.target.closest && e.target.closest('.pagination a[data-page]');
        if (!paginationLink) return;
        
        // Check if we're in the ratings section
        const ratingsSection = paginationLink.closest('#ratings-section');
        if (!ratingsSection) return;
        
        e.preventDefault();
        const page = parseInt(paginationLink.getAttribute('data-page'));
        if (page) {
            // Store current filter value before navigating
            if (ratingFilter) {
                localStorage.setItem('ratingFilterValue', ratingFilter.value);
            }
            window.location.href = 'min.php?rating_page=' + page + '#ratings-section';
        }
    });
</script>
</body>
</html>
<?php
// Close any open PDO connections
if (isset($pdo)) {
    $pdo = null;
}
?>