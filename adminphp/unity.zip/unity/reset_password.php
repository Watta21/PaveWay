<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// === Database connection ===
$host = "localhost";
$dbname = "unity_users"; 
$username = "root";      
$password = "";          

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}

$message = "";
$error = "";
$showForm = false;
$user = null;

// === Check token from URL ===
if (isset($_GET['token'])) {
    $token = trim($_GET['token']);

    if ($token !== "") {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE reset_token = ?");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Check expiry
            if ($user['reset_token_expires'] > date("Y-m-d H:i:s")) {
                $showForm = true;
            } else {
                $error = "⚠️ Reset link has expired.";
            }
        } else {
            $error = "⚠️ Invalid reset token (not found in DB).";
        }
    } else {
        $error = "⚠️ No token provided in URL.";
    }
} else {
    $error = "⚠️ Reset link is missing token parameter.";
}

// === Process new password ===
if ($showForm && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (strlen($newPassword) < 6) {
        $error = "⚠️ Password must be at least 6 characters long.";
    } elseif ($newPassword && $newPassword === $confirmPassword) {
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("UPDATE users 
                               SET password = ?, reset_token = NULL, reset_token_expires = NULL 
                               WHERE id = ?");
        $stmt->execute([$hashed, $user['id']]);

        $message = "✅ Password updated successfully. You can now <a href='login.php'>login</a>.";
        $showForm = false;
    } else {
        $error = "⚠️ Passwords do not match.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reset Password</title>
    <link rel="stylesheet" href="reset_password.css">
</head>
<body>
    <div class="reset-container">
        <h2>Reset Password</h2>

        <?php if ($message): ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <?php if ($error): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>

        <?php if ($showForm): ?>
            <form method="post">
                <input type="password" name="password" placeholder="New Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                <button type="submit">Reset Password</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
