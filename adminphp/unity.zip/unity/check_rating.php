<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "unity_users";

$conn = new mysqli($host, $user, $pass, $db);

$image_name = $_POST['image_name'] ?? '';
$username = $_POST['username'] ?? '';

if ($image_name == '' || $username == '') {
    echo json_encode(["status"=>"error"]);
    exit;
}

$stmt = $conn->prepare("SELECT rating FROM ratings WHERE image_name=? AND username=?");
$stmt->bind_param("ss", $image_name, $username);
$stmt->execute();
$result = $stmt->get_result();

$user_rating = 0;

if ($row = $result->fetch_assoc()) {
    $user_rating = intval($row['rating']);
}

echo json_encode([
    "status" => "ok",
    "user_rating" => $user_rating
]);
?>
