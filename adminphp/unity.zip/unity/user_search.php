<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/db_config.php';

$pdo = $GLOBALS['pdo'] ?? $pdo;
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$status = isset($_GET['status']) ? $_GET['status'] : 'all';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 10;
$offset = ($page - 1) * $perPage;

$whereParts = [];
$params = [];
if ($status === 'archived') {
    $whereParts[] = 'archived = 1';
} elseif ($status === 'active') {
    $whereParts[] = 'archived = 0';
}
if ($q !== '') {
    $whereParts[] = '(username LIKE ? OR email LIKE ? OR role LIKE ?)';
    $like = '%' . $q . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}
$whereClause = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';

try {
    $countSql = "SELECT COUNT(*) FROM users " . $whereClause;
    $stmtCount = $pdo->prepare($countSql);
    $stmtCount->execute($params);
    $total = (int)$stmtCount->fetchColumn();

    $selectSql = "SELECT id, username, email, created_at, status, last_seen, archived, role,
        TIMESTAMPDIFF(MINUTE, last_seen, NOW()) AS minutes_ago
        FROM users " . $whereClause . " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $stmt = $pdo->prepare($selectSql);
    $bindIndex = 1;
    foreach ($params as $p) {
        $stmt->bindValue($bindIndex++, $p, PDO::PARAM_STR);
    }
    $stmt->bindValue($bindIndex++, (int)$perPage, PDO::PARAM_INT);
    $stmt->bindValue($bindIndex++, (int)$offset, PDO::PARAM_INT);
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    ob_start();
    if (empty($users)) {
        echo '<tr class="no-results"><td colspan="6" style="text-align:center;padding:20px;color:#666;">No users found</td></tr>';
    } else {
        foreach ($users as $user) {
            $archived = $user['archived'] ? 1 : 0;
            $createdDate = date('M d, Y', strtotime($user['created_at']));
            $createdTime = date('h:i A', strtotime($user['created_at']));
            $minutesAgo = (int)$user['minutes_ago'];
            echo '<tr data-archived="' . $archived . '">';
            echo '<td><div style="display:flex;align-items:center;gap:12px;">';
            echo '<div style="width:40px;height:40px;border-radius:20px;background:' . ($user['role'] === 'admin' ? '#4e73df' : '#e2e8f0') . ';display:flex;align-items:center;justify-content:center;font-weight:600;color:' . ($user['role'] === 'admin' ? 'white' : '#4a5568') . ';">' . strtoupper(substr($user['username'],0,1)) . '</div>';
            echo '<div><div style="font-weight:500;">' . htmlspecialchars($user['username']) . '</div><div style="font-size:0.9em;color:#666;">' . htmlspecialchars($user['email']) . '</div></div>';
            echo '</div></td>';
            echo '<td><span style="display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:20px;font-size:0.85em;' . ($user['role'] === 'admin' ? 'background:#e0e7ff;color:#4338ca;' : 'background:#f1f5f9;color:#64748b;') . '">' . htmlspecialchars(ucfirst($user['role'] ?? 'user')) . '</span></td>';
            echo '<td><span class="user-status ' . ($archived ? 'archived' : 'active') . '">' . ($archived ? 'Archived' : 'Active') . '</span></td>';
            echo '<td><div style="color:#4a5568;">' . $createdDate . '</div><div style="font-size:0.9em;color:#718096;">' . $createdTime . '</div></td>';
            // actions form (include CSRF token from session)
            $csrf = isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : '';
            echo '<td><div class="action-buttons"><form method="post" style="display:inline;">';
            echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($csrf) . '" />';
            echo '<input type="hidden" name="user_id" value="' . (int)$user['id'] . '" />';
            echo '<select name="new_status" class="action-btn user-status-select" data-user-id="' . (int)$user['id'] . '" style="min-width:100px;">';
            echo '<option value="active"' . (!$archived ? ' selected' : '') . '>Active</option>';
            echo '<option value="archived"' . ($archived ? ' selected' : '') . '>Archive</option>';
            echo '</select>';
            echo '</form></div></td>';
            echo '</tr>';
        }
    }
    $html = ob_get_clean();

    // Build pagination HTML
    $totalPages = ceil($total / $perPage);
    $pagination = '';
    if ($totalPages > 1) {
        $pagination .= '<div class="pagination">';
        if ($page > 1) {
            $pagination .= '<a href="#" class="page-btn" data-page="' . ($page - 1) . '"><i class="fas fa-chevron-left"></i> Previous</a>';
        }
        $maxLinks = 5;
        $start = max(1, $page - floor($maxLinks / 2));
        $end = min($totalPages, $start + $maxLinks - 1);
        $start = max(1, min($start, $totalPages - $maxLinks + 1));
        if ($start > 1) {
            $pagination .= '<a href="#" class="page-btn" data-page="1">1</a>';
            if ($start > 2) $pagination .= '<span class="page-btn">...</span>';
        }
        for ($i = $start; $i <= $end; $i++) {
            if ($i == $page) {
                $pagination .= '<span class="page-btn active" data-page="' . $i . '">' . $i . '</span>';
            } else {
                $pagination .= '<a href="#" class="page-btn" data-page="' . $i . '">' . $i . '</a>';
            }
        }
        if ($end < $totalPages) {
            if ($end < $totalPages - 1) $pagination .= '<span class="page-btn">...</span>';
            $pagination .= '<a href="#" class="page-btn" data-page="' . $totalPages . '">' . $totalPages . '</a>';
        }
        if ($page < $totalPages) {
            $pagination .= '<a href="#" class="page-btn" data-page="' . ($page + 1) . '">Next <i class="fas fa-chevron-right"></i></a>';
        }
        $pagination .= '</div>';
    }

    echo json_encode(['total' => $total, 'page' => $page, 'per_page' => $perPage, 'html' => $html, 'pagination' => $pagination]);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['total' => 0, 'page' => $page, 'per_page' => $perPage, 'html' => '']);
    exit;
}
