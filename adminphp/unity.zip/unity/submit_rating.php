<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "unity_users";

$conn = new mysqli($host, $user, $pass, $db);

$image_name = $_POST['image_name'] ?? '';
$username = $_POST['username'] ?? '';
$rating = intval($_POST['rating'] ?? 0);
$delete = intval($_POST['delete'] ?? 0);

if ($image_name == '' || $username == '') die(json_encode(["status"=>"error"]));

// Unrate
if ($delete === 1) {
    $stmt = $conn->prepare("DELETE FROM ratings WHERE image_name=? AND username=?");
    $stmt->bind_param("ss", $image_name, $username);
    $stmt->execute();
    $status = "deleted";
}
// Rate
else if ($rating > 0) {
    $stmt = $conn->prepare("SELECT * FROM ratings WHERE image_name=? AND username=?");
    $stmt->bind_param("ss", $image_name, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Update rating if user already rated
        $stmt = $conn->prepare("UPDATE ratings SET rating=? WHERE image_name=? AND username=?");
        $stmt->bind_param("iss", $rating, $image_name, $username);
        $stmt->execute();
        $status = "updated";
    } else {
        // Insert new rating
        $stmt = $conn->prepare("INSERT INTO ratings (image_name, username, rating) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $image_name, $username, $rating);
        $stmt->execute();
        $status = "inserted";
    }
}

// Get average, total users, total stars for this image
$res = $conn->query("SELECT AVG(rating) AS avg_rating, COUNT(*) AS total_users, SUM(rating) AS total_stars 
                     FROM ratings WHERE image_name='$image_name'")->fetch_assoc();

// Get this user's rating
$user_rating = $conn->query("SELECT rating FROM ratings WHERE image_name='$image_name' AND username='$username'")
                     ->fetch_assoc()['rating'] ?? 0;

echo json_encode([
    "status"=>$status,
    "avg_rating"=>round((float)($res['avg_rating'] ?? 0),1),
    "total_users"=>intval($res['total_users'] ?? 0),
    "total_stars"=>intval($res['total_stars'] ?? 0),
    "user_rating"=>intval($user_rating)
]);
?>
